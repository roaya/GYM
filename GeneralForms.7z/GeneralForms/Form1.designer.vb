﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PanelSettings = New System.Windows.Forms.Panel()
        Me.BtnLocations = New System.Windows.Forms.Button()
        Me.ButtonsImages = New System.Windows.Forms.ImageList(Me.components)
        Me.BtnRegions = New System.Windows.Forms.Button()
        Me.BtnCities = New System.Windows.Forms.Button()
        Me.BtnCountries = New System.Windows.Forms.Button()
        Me.BtnSetDefault = New System.Windows.Forms.Button()
        Me.BtnSystemCommands = New System.Windows.Forms.Button()
        Me.BtnChatServer = New System.Windows.Forms.Button()
        Me.BtnChatClient = New System.Windows.Forms.Button()
        Me.BtnShiftsDetails = New System.Windows.Forms.Button()
        Me.BtnShifts = New System.Windows.Forms.Button()
        Me.BtnSettings = New System.Windows.Forms.Button()
        Me.PanelSecurity = New System.Windows.Forms.Panel()
        Me.BtnApp_Users = New System.Windows.Forms.Button()
        Me.BtnSecurityGroupDetails = New System.Windows.Forms.Button()
        Me.BtnSecurityGroupHeader = New System.Windows.Forms.Button()
        Me.PanelEmployees = New System.Windows.Forms.Panel()
        Me.BtnSalaryGroups = New System.Windows.Forms.Button()
        Me.BtnAttendanceLeave = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.BtnEmployeesDiscounts = New System.Windows.Forms.Button()
        Me.BtnDiscountCatergories = New System.Windows.Forms.Button()
        Me.MenuDiscounts = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.BtnEmpRewards = New System.Windows.Forms.Button()
        Me.BtnRewardsCategories = New System.Windows.Forms.Button()
        Me.MenuRewards = New System.Windows.Forms.Button()
        Me.BtnTasks = New System.Windows.Forms.Button()
        Me.BtnVacations = New System.Windows.Forms.Button()
        Me.BtnAttendance = New System.Windows.Forms.Button()
        Me.BtnEmployees = New System.Windows.Forms.Button()
        Me.BtnJobs = New System.Windows.Forms.Button()
        Me.BtnDepartments = New System.Windows.Forms.Button()
        Me.PanelReports = New System.Windows.Forms.Panel()
        Me.BtnPrintEmpCards = New System.Windows.Forms.Button()
        Me.BtnPrintBarcode = New System.Windows.Forms.Button()
        Me.BtnBackCard = New System.Windows.Forms.Button()
        Me.btnreportEmployees = New System.Windows.Forms.Button()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.BtnRptAccountsBalance = New System.Windows.Forms.Button()
        Me.BtnAnyAccount = New System.Windows.Forms.Button()
        Me.BtnReportItemExpiration = New System.Windows.Forms.Button()
        Me.BtnStockDetails = New System.Windows.Forms.Button()
        Me.BtnGeneralBalance = New System.Windows.Forms.Button()
        Me.BtnRptItemsUm = New System.Windows.Forms.Button()
        Me.BtnRptStockValue = New System.Windows.Forms.Button()
        Me.BtnRptUserLog = New System.Windows.Forms.Button()
        Me.BtnRptInvLog = New System.Windows.Forms.Button()
        Me.BtnRptDepItems = New System.Windows.Forms.Button()
        Me.BtnRptBarcode = New System.Windows.Forms.Button()
        Me.BtnRptSalesOrder = New System.Windows.Forms.Button()
        Me.BtnRptCustomersReturns = New System.Windows.Forms.Button()
        Me.BtnRptVendorReturns = New System.Windows.Forms.Button()
        Me.BtnRptPurchaseOrder = New System.Windows.Forms.Button()
        Me.BtnRptAdjustments = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.BtnGymReports = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.BtnActivatePanel = New System.Windows.Forms.Button()
        Me.PanelAccounting = New System.Windows.Forms.Panel()
        Me.RptIncome = New System.Windows.Forms.Button()
        Me.BtnPaySalary = New System.Windows.Forms.Button()
        Me.BtnPayAllSalaries = New System.Windows.Forms.Button()
        Me.MenuEmpAccounts = New System.Windows.Forms.Button()
        Me.MenuDepPro = New System.Windows.Forms.Button()
        Me.MenuBalanceSheet = New System.Windows.Forms.Button()
        Me.MenuBalanceBook = New System.Windows.Forms.Button()
        Me.MenuMasterRecord = New System.Windows.Forms.Button()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.MenuMoneyReceivable = New System.Windows.Forms.Button()
        Me.MenuMoneyPayments = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.MenuBanks = New System.Windows.Forms.Button()
        Me.MenuBanksAccounts = New System.Windows.Forms.Button()
        Me.BtnVisa = New System.Windows.Forms.Button()
        Me.Banks = New System.Windows.Forms.Button()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.MenuCheques = New System.Windows.Forms.Button()
        Me.MenuChequeStatus = New System.Windows.Forms.Button()
        Me.Cheques = New System.Windows.Forms.Button()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.MenuDailyProcedures = New System.Windows.Forms.Button()
        Me.MenuNewProcedureTran = New System.Windows.Forms.Button()
        Me.constraint = New System.Windows.Forms.Button()
        Me.MenuDailyProNames = New System.Windows.Forms.Button()
        Me.MenuIncomeDetailsByPeriod = New System.Windows.Forms.Button()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.MenuExpensesOther = New System.Windows.Forms.Button()
        Me.MenuExpensesHeader = New System.Windows.Forms.Button()
        Me.MenuExpenses = New System.Windows.Forms.Button()
        Me.PanelStatistics = New System.Windows.Forms.Panel()
        Me.PanelCustomer = New System.Windows.Forms.Panel()
        Me.BntSubscReturn = New System.Windows.Forms.Button()
        Me.BtnCompanies = New System.Windows.Forms.Button()
        Me.BtnCustOrderEvaluation = New System.Windows.Forms.Button()
        Me.BtnCustEvaluation = New System.Windows.Forms.Button()
        Me.BtnEvaluationCategory = New System.Windows.Forms.Button()
        Me.BtnSpecialSub = New System.Windows.Forms.Button()
        Me.BtnSpecialSubCa = New System.Windows.Forms.Button()
        Me.BtnCustomersAttendance = New System.Windows.Forms.Button()
        Me.BtnSubDaily = New System.Windows.Forms.Button()
        Me.BtnCustomerSubscription = New System.Windows.Forms.Button()
        Me.BtnSubscriptions = New System.Windows.Forms.Button()
        Me.BtnSubscripionsCategories = New System.Windows.Forms.Button()
        Me.BtnCustomerReturns = New System.Windows.Forms.Button()
        Me.BtnSalesOrder = New System.Windows.Forms.Button()
        Me.BtnCustomers = New System.Windows.Forms.Button()
        Me.PanelStock = New System.Windows.Forms.Panel()
        Me.BtnAdjustments = New System.Windows.Forms.Button()
        Me.BtnCheckDetails = New System.Windows.Forms.Button()
        Me.BtnCheckHeader = New System.Windows.Forms.Button()
        Me.BtnItemsOut = New System.Windows.Forms.Button()
        Me.BtnStocks = New System.Windows.Forms.Button()
        Me.BtnCategories = New System.Windows.Forms.Button()
        Me.BtnItemsStocks = New System.Windows.Forms.Button()
        Me.BtnUmDetails = New System.Windows.Forms.Button()
        Me.BtnUmMaster = New System.Windows.Forms.Button()
        Me.BtnCorporations = New System.Windows.Forms.Button()
        Me.BtnItems = New System.Windows.Forms.Button()
        Me.PanelVendor = New System.Windows.Forms.Panel()
        Me.BtnVendorReturns = New System.Windows.Forms.Button()
        Me.BtnPurchaseBill = New System.Windows.Forms.Button()
        Me.BtnItemsVendor = New System.Windows.Forms.Button()
        Me.BtnVendors = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.btnReceiv = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CustBalance = New System.Windows.Forms.TextBox()
        Me.CustAttendance = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Cost = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.dailysubsc = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.bydaily = New System.Windows.Forms.RadioButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Subscription_ID = New System.Windows.Forms.ComboBox()
        Me.bysubsc = New System.Windows.Forms.RadioButton()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.coach = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.EmpBarcode = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.custcode = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.custname = New System.Windows.Forms.TextBox()
        Me.SearchBox = New System.Windows.Forms.TextBox()
        Me.PanelSearch = New System.Windows.Forms.Panel()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GrdSearchDetails = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GrdSearch = New System.Windows.Forms.DataGridView()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.BtnEmp = New System.Windows.Forms.ToolStripButton()
        Me.BtnStock = New System.Windows.Forms.ToolStripButton()
        Me.BtnCust = New System.Windows.Forms.ToolStripButton()
        Me.BtnMedecine = New System.Windows.Forms.ToolStripButton()
        Me.BtnAccounting = New System.Windows.Forms.ToolStripButton()
        Me.BtnMost = New System.Windows.Forms.ToolStripButton()
        Me.BtnReport = New System.Windows.Forms.ToolStripButton()
        Me.BtnSecurity = New System.Windows.Forms.ToolStripButton()
        Me.Show_Hide = New System.Windows.Forms.ToolStripButton()
        Me.Button1 = New System.Windows.Forms.ToolStripButton()
        Me.PanelSettings.SuspendLayout
        Me.PanelSecurity.SuspendLayout
        Me.PanelEmployees.SuspendLayout
        Me.Panel1.SuspendLayout
        Me.Panel20.SuspendLayout
        Me.Panel4.SuspendLayout
        Me.PanelReports.SuspendLayout
        Me.Panel8.SuspendLayout
        Me.Panel5.SuspendLayout
        Me.PanelAccounting.SuspendLayout
        Me.Panel19.SuspendLayout
        Me.Panel18.SuspendLayout
        Me.Panel17.SuspendLayout
        Me.Panel16.SuspendLayout
        Me.Panel10.SuspendLayout
        Me.PanelCustomer.SuspendLayout
        Me.PanelStock.SuspendLayout
        Me.PanelVendor.SuspendLayout
        Me.Panel2.SuspendLayout
        Me.Panel7.SuspendLayout
        Me.Panel6.SuspendLayout
        Me.Panel3.SuspendLayout
        Me.GroupBox5.SuspendLayout
        Me.GroupBox1.SuspendLayout
        Me.GroupBox4.SuspendLayout
        Me.PanelSearch.SuspendLayout
        Me.GroupBox3.SuspendLayout
        CType(Me.GrdSearchDetails,System.ComponentModel.ISupportInitialize).BeginInit
        Me.GroupBox2.SuspendLayout
        CType(Me.GrdSearch,System.ComponentModel.ISupportInitialize).BeginInit
        Me.ToolStrip1.SuspendLayout
        Me.SuspendLayout
        '
        'PanelSettings
        '
        Me.PanelSettings.BackColor = System.Drawing.Color.Transparent
        Me.PanelSettings.Controls.Add(Me.BtnLocations)
        Me.PanelSettings.Controls.Add(Me.BtnRegions)
        Me.PanelSettings.Controls.Add(Me.BtnCities)
        Me.PanelSettings.Controls.Add(Me.BtnCountries)
        Me.PanelSettings.Controls.Add(Me.BtnSetDefault)
        Me.PanelSettings.Controls.Add(Me.BtnSystemCommands)
        Me.PanelSettings.Controls.Add(Me.BtnChatServer)
        Me.PanelSettings.Controls.Add(Me.BtnChatClient)
        Me.PanelSettings.Controls.Add(Me.BtnShiftsDetails)
        Me.PanelSettings.Controls.Add(Me.BtnShifts)
        Me.PanelSettings.Controls.Add(Me.BtnSettings)
        Me.PanelSettings.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelSettings.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.PanelSettings.ForeColor = System.Drawing.Color.White
        Me.PanelSettings.Location = New System.Drawing.Point(0, 0)
        Me.PanelSettings.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelSettings.Name = "PanelSettings"
        Me.PanelSettings.Size = New System.Drawing.Size(281, 838)
        Me.PanelSettings.TabIndex = 51
        Me.PanelSettings.Visible = false
        '
        'BtnLocations
        '
        Me.BtnLocations.BackgroundImage = CType(resources.GetObject("BtnLocations.BackgroundImage"),System.Drawing.Image)
        Me.BtnLocations.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnLocations.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnLocations.FlatAppearance.BorderSize = 0
        Me.BtnLocations.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnLocations.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnLocations.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnLocations.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnLocations.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnLocations.ImageKey = "(none)"
        Me.BtnLocations.ImageList = Me.ButtonsImages
        Me.BtnLocations.Location = New System.Drawing.Point(0, 383)
        Me.BtnLocations.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnLocations.Name = "BtnLocations"
        Me.BtnLocations.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnLocations.Size = New System.Drawing.Size(281, 38)
        Me.BtnLocations.TabIndex = 38
        Me.BtnLocations.Text = "الأحياء"
        Me.BtnLocations.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnLocations.UseVisualStyleBackColor = true
        '
        'ButtonsImages
        '
        Me.ButtonsImages.ImageStream = CType(resources.GetObject("ButtonsImages.ImageStream"),System.Windows.Forms.ImageListStreamer)
        Me.ButtonsImages.TransparentColor = System.Drawing.Color.Transparent
        Me.ButtonsImages.Images.SetKeyName(0, "27-Edit Text.png")
        Me.ButtonsImages.Images.SetKeyName(1, "224258-system-help-512.png")
        Me.ButtonsImages.Images.SetKeyName(2, "1370447158_Add.png")
        Me.ButtonsImages.Images.SetKeyName(3, "1370447608_button_cancel.png")
        Me.ButtonsImages.Images.SetKeyName(4, "Actions-resource-group-icon.png")
        Me.ButtonsImages.Images.SetKeyName(5, "Add.png")
        Me.ButtonsImages.Images.SetKeyName(6, "add1.png")
        Me.ButtonsImages.Images.SetKeyName(7, "add2.png")
        Me.ButtonsImages.Images.SetKeyName(8, "add2-.png")
        Me.ButtonsImages.Images.SetKeyName(9, "AdobeApplicationManager_file_document.png")
        Me.ButtonsImages.Images.SetKeyName(10, "applications-engineering.png")
        Me.ButtonsImages.Images.SetKeyName(11, "Blog_Artdesigner.png")
        Me.ButtonsImages.Images.SetKeyName(12, "boxing-gloves-icon.png")
        Me.ButtonsImages.Images.SetKeyName(13, "Boxing-Gloves-icon1.png")
        Me.ButtonsImages.Images.SetKeyName(14, "Company.png")
        Me.ButtonsImages.Images.SetKeyName(15, "company-building-icon.png")
        Me.ButtonsImages.Images.SetKeyName(16, "CSS-Edit.png")
        Me.ButtonsImages.Images.SetKeyName(17, "Customer_Male_Light.png")
        Me.ButtonsImages.Images.SetKeyName(18, "data_management.png")
        Me.ButtonsImages.Images.SetKeyName(19, "desktop.png")
        Me.ButtonsImages.Images.SetKeyName(20, "e06c71d37c0252389aa28c2fc2b6cf2c.png")
        Me.ButtonsImages.Images.SetKeyName(21, "edit_add.png")
        Me.ButtonsImages.Images.SetKeyName(22, "Error.png")
        Me.ButtonsImages.Images.SetKeyName(23, "exit.png")
        Me.ButtonsImages.Images.SetKeyName(24, "file-manager.png")
        Me.ButtonsImages.Images.SetKeyName(25, "filesaveas.png")
        Me.ButtonsImages.Images.SetKeyName(26, "fitness_icon.png")
        Me.ButtonsImages.Images.SetKeyName(27, "Flash_file_document.png")
        Me.ButtonsImages.Images.SetKeyName(28, "flowers_xochi_hotel_icon_gym_gerald_g_1_icons-1331px.png")
        Me.ButtonsImages.Images.SetKeyName(29, "folder_data.png")
        Me.ButtonsImages.Images.SetKeyName(30, "Folder_Subscriptions.png")
        Me.ButtonsImages.Images.SetKeyName(31, "gnome-help.png")
        Me.ButtonsImages.Images.SetKeyName(32, "gnome-help1.png")
        Me.ButtonsImages.Images.SetKeyName(33, "Groups-Meeting-Dark-icon.png")
        Me.ButtonsImages.Images.SetKeyName(34, "Groups-Military-Personnel-Light-icon.png")
        Me.ButtonsImages.Images.SetKeyName(35, "Groups-Rescuers-Dark-icon.png")
        Me.ButtonsImages.Images.SetKeyName(36, "Groups-Rescuers-Light-icon.png")
        Me.ButtonsImages.Images.SetKeyName(37, "gym.png")
        Me.ButtonsImages.Images.SetKeyName(38, "Help.png")
        Me.ButtonsImages.Images.SetKeyName(39, "help_index.png")
        Me.ButtonsImages.Images.SetKeyName(40, "Help-File.png")
        Me.ButtonsImages.Images.SetKeyName(41, "holiday-icon.png")
        Me.ButtonsImages.Images.SetKeyName(42, "holidays.png")
        Me.ButtonsImages.Images.SetKeyName(43, "invoice.png")
        Me.ButtonsImages.Images.SetKeyName(44, "Log Out.png")
        Me.ButtonsImages.Images.SetKeyName(45, "Log Out1.png")
        Me.ButtonsImages.Images.SetKeyName(46, "logoLifter.png")
        Me.ButtonsImages.Images.SetKeyName(47, "Manager.png")
        Me.ButtonsImages.Images.SetKeyName(48, "mzl.xwvncbhw.png")
        Me.ButtonsImages.Images.SetKeyName(49, "Plus__Orange.png")
        Me.ButtonsImages.Images.SetKeyName(50, "plus_add_blue.png")
        Me.ButtonsImages.Images.SetKeyName(51, "plus_add_green.png")
        Me.ButtonsImages.Images.SetKeyName(52, "Save.png")
        Me.ButtonsImages.Images.SetKeyName(53, "save1.png")
        Me.ButtonsImages.Images.SetKeyName(54, "Save2.png")
        Me.ButtonsImages.Images.SetKeyName(55, "Status-mail-task-icon.png")
        Me.ButtonsImages.Images.SetKeyName(56, "stock_save-as.png")
        Me.ButtonsImages.Images.SetKeyName(57, "weightlifting-icon.png")
        Me.ButtonsImages.Images.SetKeyName(58, "xfce-system-exit.png")
        Me.ButtonsImages.Images.SetKeyName(59, "money-icon.png")
        Me.ButtonsImages.Images.SetKeyName(60, "Coins-icon.png")
        Me.ButtonsImages.Images.SetKeyName(61, "payment-icon.png")
        Me.ButtonsImages.Images.SetKeyName(62, "appointment-missed.png")
        Me.ButtonsImages.Images.SetKeyName(63, "clock.png")
        Me.ButtonsImages.Images.SetKeyName(64, "banker.png")
        Me.ButtonsImages.Images.SetKeyName(65, "062.png")
        Me.ButtonsImages.Images.SetKeyName(66, "Profit_3D-512.png")
        Me.ButtonsImages.Images.SetKeyName(67, "06.png")
        Me.ButtonsImages.Images.SetKeyName(68, "db_remove.png")
        Me.ButtonsImages.Images.SetKeyName(69, "Windows_View_Detail.png")
        Me.ButtonsImages.Images.SetKeyName(70, "weight.png")
        Me.ButtonsImages.Images.SetKeyName(71, "cart.png")
        Me.ButtonsImages.Images.SetKeyName(72, "1370453460_shoppingbasket_add.png")
        Me.ButtonsImages.Images.SetKeyName(73, "shopping-cart.png")
        Me.ButtonsImages.Images.SetKeyName(74, "Coffee-Shop-icon.png")
        Me.ButtonsImages.Images.SetKeyName(75, "xoops-destroy.png")
        Me.ButtonsImages.Images.SetKeyName(76, "file_add.png")
        Me.ButtonsImages.Images.SetKeyName(77, "stock_task.png")
        Me.ButtonsImages.Images.SetKeyName(78, "Document-Add-icon.png")
        Me.ButtonsImages.Images.SetKeyName(79, "Panneau-destroy.png")
        Me.ButtonsImages.Images.SetKeyName(80, "stock_folder-move.png")
        Me.ButtonsImages.Images.SetKeyName(81, "New-room-icon.png")
        Me.ButtonsImages.Images.SetKeyName(82, "folder-subscriptions-icon.png")
        Me.ButtonsImages.Images.SetKeyName(83, "Mimetypes-text-directory-icon.png")
        Me.ButtonsImages.Images.SetKeyName(84, "directory-icon.png")
        Me.ButtonsImages.Images.SetKeyName(85, "Program-Group-icon.png")
        Me.ButtonsImages.Images.SetKeyName(86, "It-Infrastructure-Active-directory-icon.png")
        Me.ButtonsImages.Images.SetKeyName(87, "Misc-Misc-Stuff-icon.png")
        Me.ButtonsImages.Images.SetKeyName(88, "Login Manager.png")
        Me.ButtonsImages.Images.SetKeyName(89, "Supervisor.png")
        Me.ButtonsImages.Images.SetKeyName(90, "mypc_reload.png")
        Me.ButtonsImages.Images.SetKeyName(91, "network_reload.png")
        Me.ButtonsImages.Images.SetKeyName(92, "user_accounts_help.png")
        Me.ButtonsImages.Images.SetKeyName(93, "Bank_account.png")
        Me.ButtonsImages.Images.SetKeyName(94, "bank.png")
        Me.ButtonsImages.Images.SetKeyName(95, "cheque-icon.png")
        Me.ButtonsImages.Images.SetKeyName(96, "payment-card.png")
        Me.ButtonsImages.Images.SetKeyName(97, "Money1.png")
        Me.ButtonsImages.Images.SetKeyName(98, "income-icon.png")
        Me.ButtonsImages.Images.SetKeyName(99, "Money.png")
        Me.ButtonsImages.Images.SetKeyName(100, "Transaction_3D-512.png")
        Me.ButtonsImages.Images.SetKeyName(101, "competitors.png")
        Me.ButtonsImages.Images.SetKeyName(102, "Properties.png")
        Me.ButtonsImages.Images.SetKeyName(103, "Proposal-512.png")
        Me.ButtonsImages.Images.SetKeyName(104, "client_account_template.png")
        Me.ButtonsImages.Images.SetKeyName(105, "Sheet-of-paper-icon.png")
        Me.ButtonsImages.Images.SetKeyName(106, "Balance-icon.png")
        Me.ButtonsImages.Images.SetKeyName(107, "client_account_template.png")
        Me.ButtonsImages.Images.SetKeyName(108, "1370457161_BeOS_blocks.png")
        Me.ButtonsImages.Images.SetKeyName(109, "1370457133_BeOS_app_serv.png")
        Me.ButtonsImages.Images.SetKeyName(110, "config-users.png")
        Me.ButtonsImages.Images.SetKeyName(111, "default-applications-capplet.png")
        Me.ButtonsImages.Images.SetKeyName(112, "order-history.png")
        Me.ButtonsImages.Images.SetKeyName(113, "System_Preferences.png")
        Me.ButtonsImages.Images.SetKeyName(114, "chat.png")
        Me.ButtonsImages.Images.SetKeyName(115, "amsn.png")
        Me.ButtonsImages.Images.SetKeyName(116, "advancedsettings.png")
        Me.ButtonsImages.Images.SetKeyName(117, "Balloon Without Logo.png")
        Me.ButtonsImages.Images.SetKeyName(118, "package_games_rpg.png")
        Me.ButtonsImages.Images.SetKeyName(119, "Login Manager2.png")
        Me.ButtonsImages.Images.SetKeyName(120, "application-pgp-signature.png")
        Me.ButtonsImages.Images.SetKeyName(121, "up-icon.png")
        '
        'BtnRegions
        '
        Me.BtnRegions.BackgroundImage = CType(resources.GetObject("BtnRegions.BackgroundImage"),System.Drawing.Image)
        Me.BtnRegions.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRegions.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRegions.FlatAppearance.BorderSize = 0
        Me.BtnRegions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRegions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRegions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRegions.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRegions.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnRegions.ImageKey = "(none)"
        Me.BtnRegions.ImageList = Me.ButtonsImages
        Me.BtnRegions.Location = New System.Drawing.Point(0, 345)
        Me.BtnRegions.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRegions.Name = "BtnRegions"
        Me.BtnRegions.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRegions.Size = New System.Drawing.Size(281, 38)
        Me.BtnRegions.TabIndex = 37
        Me.BtnRegions.Text = "المناطق"
        Me.BtnRegions.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRegions.UseVisualStyleBackColor = true
        '
        'BtnCities
        '
        Me.BtnCities.BackgroundImage = CType(resources.GetObject("BtnCities.BackgroundImage"),System.Drawing.Image)
        Me.BtnCities.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCities.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCities.FlatAppearance.BorderSize = 0
        Me.BtnCities.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCities.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCities.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCities.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCities.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnCities.ImageKey = "(none)"
        Me.BtnCities.ImageList = Me.ButtonsImages
        Me.BtnCities.Location = New System.Drawing.Point(0, 307)
        Me.BtnCities.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCities.Name = "BtnCities"
        Me.BtnCities.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnCities.Size = New System.Drawing.Size(281, 38)
        Me.BtnCities.TabIndex = 36
        Me.BtnCities.Text = "المدن"
        Me.BtnCities.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnCities.UseVisualStyleBackColor = true
        '
        'BtnCountries
        '
        Me.BtnCountries.BackgroundImage = CType(resources.GetObject("BtnCountries.BackgroundImage"),System.Drawing.Image)
        Me.BtnCountries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCountries.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCountries.FlatAppearance.BorderSize = 0
        Me.BtnCountries.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCountries.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCountries.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCountries.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCountries.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnCountries.ImageKey = "(none)"
        Me.BtnCountries.ImageList = Me.ButtonsImages
        Me.BtnCountries.Location = New System.Drawing.Point(0, 269)
        Me.BtnCountries.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCountries.Name = "BtnCountries"
        Me.BtnCountries.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnCountries.Size = New System.Drawing.Size(281, 38)
        Me.BtnCountries.TabIndex = 35
        Me.BtnCountries.Text = "الدول"
        Me.BtnCountries.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnCountries.UseVisualStyleBackColor = true
        '
        'BtnSetDefault
        '
        Me.BtnSetDefault.BackgroundImage = CType(resources.GetObject("BtnSetDefault.BackgroundImage"),System.Drawing.Image)
        Me.BtnSetDefault.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSetDefault.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSetDefault.FlatAppearance.BorderSize = 0
        Me.BtnSetDefault.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSetDefault.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSetDefault.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSetDefault.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSetDefault.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnSetDefault.ImageKey = "default-applications-capplet.png"
        Me.BtnSetDefault.ImageList = Me.ButtonsImages
        Me.BtnSetDefault.Location = New System.Drawing.Point(0, 231)
        Me.BtnSetDefault.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSetDefault.Name = "BtnSetDefault"
        Me.BtnSetDefault.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnSetDefault.Size = New System.Drawing.Size(281, 38)
        Me.BtnSetDefault.TabIndex = 29
        Me.BtnSetDefault.Text = "الوضع الإفتراضى"
        Me.BtnSetDefault.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnSetDefault.UseVisualStyleBackColor = true
        '
        'BtnSystemCommands
        '
        Me.BtnSystemCommands.BackgroundImage = CType(resources.GetObject("BtnSystemCommands.BackgroundImage"),System.Drawing.Image)
        Me.BtnSystemCommands.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSystemCommands.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSystemCommands.FlatAppearance.BorderSize = 0
        Me.BtnSystemCommands.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSystemCommands.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSystemCommands.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSystemCommands.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSystemCommands.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnSystemCommands.ImageKey = "order-history.png"
        Me.BtnSystemCommands.ImageList = Me.ButtonsImages
        Me.BtnSystemCommands.Location = New System.Drawing.Point(0, 193)
        Me.BtnSystemCommands.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSystemCommands.Name = "BtnSystemCommands"
        Me.BtnSystemCommands.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnSystemCommands.Size = New System.Drawing.Size(281, 38)
        Me.BtnSystemCommands.TabIndex = 30
        Me.BtnSystemCommands.Text = "اوامر النظام"
        Me.BtnSystemCommands.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnSystemCommands.UseVisualStyleBackColor = true
        '
        'BtnChatServer
        '
        Me.BtnChatServer.BackgroundImage = CType(resources.GetObject("BtnChatServer.BackgroundImage"),System.Drawing.Image)
        Me.BtnChatServer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnChatServer.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnChatServer.FlatAppearance.BorderSize = 0
        Me.BtnChatServer.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnChatServer.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnChatServer.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnChatServer.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnChatServer.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnChatServer.ImageKey = "Balloon Without Logo.png"
        Me.BtnChatServer.ImageList = Me.ButtonsImages
        Me.BtnChatServer.Location = New System.Drawing.Point(0, 155)
        Me.BtnChatServer.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnChatServer.Name = "BtnChatServer"
        Me.BtnChatServer.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnChatServer.Size = New System.Drawing.Size(281, 38)
        Me.BtnChatServer.TabIndex = 31
        Me.BtnChatServer.Text = "تشغيل سيرفر الشات"
        Me.BtnChatServer.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnChatServer.UseVisualStyleBackColor = true
        '
        'BtnChatClient
        '
        Me.BtnChatClient.BackgroundImage = CType(resources.GetObject("BtnChatClient.BackgroundImage"),System.Drawing.Image)
        Me.BtnChatClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnChatClient.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnChatClient.FlatAppearance.BorderSize = 0
        Me.BtnChatClient.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnChatClient.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnChatClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnChatClient.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnChatClient.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnChatClient.ImageKey = "amsn.png"
        Me.BtnChatClient.ImageList = Me.ButtonsImages
        Me.BtnChatClient.Location = New System.Drawing.Point(0, 117)
        Me.BtnChatClient.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnChatClient.Name = "BtnChatClient"
        Me.BtnChatClient.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnChatClient.Size = New System.Drawing.Size(281, 38)
        Me.BtnChatClient.TabIndex = 32
        Me.BtnChatClient.Text = "الدخول للشات"
        Me.BtnChatClient.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnChatClient.UseVisualStyleBackColor = true
        '
        'BtnShiftsDetails
        '
        Me.BtnShiftsDetails.BackgroundImage = CType(resources.GetObject("BtnShiftsDetails.BackgroundImage"),System.Drawing.Image)
        Me.BtnShiftsDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnShiftsDetails.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnShiftsDetails.FlatAppearance.BorderSize = 0
        Me.BtnShiftsDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnShiftsDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnShiftsDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnShiftsDetails.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnShiftsDetails.Location = New System.Drawing.Point(0, 79)
        Me.BtnShiftsDetails.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnShiftsDetails.Name = "BtnShiftsDetails"
        Me.BtnShiftsDetails.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnShiftsDetails.Size = New System.Drawing.Size(281, 38)
        Me.BtnShiftsDetails.TabIndex = 33
        Me.BtnShiftsDetails.Text = "تفاصيل الورديه "
        Me.BtnShiftsDetails.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnShiftsDetails.UseVisualStyleBackColor = true
        '
        'BtnShifts
        '
        Me.BtnShifts.BackgroundImage = CType(resources.GetObject("BtnShifts.BackgroundImage"),System.Drawing.Image)
        Me.BtnShifts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnShifts.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnShifts.FlatAppearance.BorderSize = 0
        Me.BtnShifts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnShifts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnShifts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnShifts.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnShifts.Location = New System.Drawing.Point(0, 41)
        Me.BtnShifts.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnShifts.Name = "BtnShifts"
        Me.BtnShifts.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnShifts.Size = New System.Drawing.Size(281, 38)
        Me.BtnShifts.TabIndex = 21
        Me.BtnShifts.Text = "نوع الورديه"
        Me.BtnShifts.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnShifts.UseVisualStyleBackColor = true
        '
        'BtnSettings
        '
        Me.BtnSettings.BackgroundImage = CType(resources.GetObject("BtnSettings.BackgroundImage"),System.Drawing.Image)
        Me.BtnSettings.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSettings.FlatAppearance.BorderSize = 0
        Me.BtnSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSettings.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSettings.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnSettings.ImageKey = "System_Preferences.png"
        Me.BtnSettings.ImageList = Me.ButtonsImages
        Me.BtnSettings.Location = New System.Drawing.Point(0, 0)
        Me.BtnSettings.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSettings.Name = "BtnSettings"
        Me.BtnSettings.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnSettings.Size = New System.Drawing.Size(281, 41)
        Me.BtnSettings.TabIndex = 27
        Me.BtnSettings.Text = "إعدادات البرنامج"
        Me.BtnSettings.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnSettings.UseVisualStyleBackColor = true
        '
        'PanelSecurity
        '
        Me.PanelSecurity.BackColor = System.Drawing.Color.Transparent
        Me.PanelSecurity.Controls.Add(Me.BtnApp_Users)
        Me.PanelSecurity.Controls.Add(Me.BtnSecurityGroupDetails)
        Me.PanelSecurity.Controls.Add(Me.BtnSecurityGroupHeader)
        Me.PanelSecurity.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelSecurity.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.PanelSecurity.ForeColor = System.Drawing.Color.White
        Me.PanelSecurity.Location = New System.Drawing.Point(0, 0)
        Me.PanelSecurity.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelSecurity.Name = "PanelSecurity"
        Me.PanelSecurity.Size = New System.Drawing.Size(281, 838)
        Me.PanelSecurity.TabIndex = 50
        Me.PanelSecurity.Visible = false
        '
        'BtnApp_Users
        '
        Me.BtnApp_Users.BackgroundImage = CType(resources.GetObject("BtnApp_Users.BackgroundImage"),System.Drawing.Image)
        Me.BtnApp_Users.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnApp_Users.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnApp_Users.FlatAppearance.BorderSize = 0
        Me.BtnApp_Users.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnApp_Users.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnApp_Users.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnApp_Users.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnApp_Users.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnApp_Users.ImageKey = "package_games_rpg.png"
        Me.BtnApp_Users.ImageList = Me.ButtonsImages
        Me.BtnApp_Users.Location = New System.Drawing.Point(0, 79)
        Me.BtnApp_Users.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnApp_Users.Name = "BtnApp_Users"
        Me.BtnApp_Users.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnApp_Users.Size = New System.Drawing.Size(281, 38)
        Me.BtnApp_Users.TabIndex = 29
        Me.BtnApp_Users.Text = "بيانات المستخدميين"
        Me.BtnApp_Users.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnApp_Users.UseVisualStyleBackColor = true
        '
        'BtnSecurityGroupDetails
        '
        Me.BtnSecurityGroupDetails.BackgroundImage = CType(resources.GetObject("BtnSecurityGroupDetails.BackgroundImage"),System.Drawing.Image)
        Me.BtnSecurityGroupDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSecurityGroupDetails.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSecurityGroupDetails.FlatAppearance.BorderSize = 0
        Me.BtnSecurityGroupDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSecurityGroupDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSecurityGroupDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSecurityGroupDetails.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSecurityGroupDetails.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnSecurityGroupDetails.ImageKey = "Login Manager2.png"
        Me.BtnSecurityGroupDetails.ImageList = Me.ButtonsImages
        Me.BtnSecurityGroupDetails.Location = New System.Drawing.Point(0, 41)
        Me.BtnSecurityGroupDetails.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSecurityGroupDetails.Name = "BtnSecurityGroupDetails"
        Me.BtnSecurityGroupDetails.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnSecurityGroupDetails.Size = New System.Drawing.Size(281, 38)
        Me.BtnSecurityGroupDetails.TabIndex = 21
        Me.BtnSecurityGroupDetails.Text = "صلاحيات مجموعه الآمان"
        Me.BtnSecurityGroupDetails.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnSecurityGroupDetails.UseVisualStyleBackColor = true
        '
        'BtnSecurityGroupHeader
        '
        Me.BtnSecurityGroupHeader.BackgroundImage = CType(resources.GetObject("BtnSecurityGroupHeader.BackgroundImage"),System.Drawing.Image)
        Me.BtnSecurityGroupHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSecurityGroupHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSecurityGroupHeader.FlatAppearance.BorderSize = 0
        Me.BtnSecurityGroupHeader.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSecurityGroupHeader.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSecurityGroupHeader.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSecurityGroupHeader.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSecurityGroupHeader.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.BtnSecurityGroupHeader.ImageKey = "application-pgp-signature.png"
        Me.BtnSecurityGroupHeader.ImageList = Me.ButtonsImages
        Me.BtnSecurityGroupHeader.Location = New System.Drawing.Point(0, 0)
        Me.BtnSecurityGroupHeader.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSecurityGroupHeader.Name = "BtnSecurityGroupHeader"
        Me.BtnSecurityGroupHeader.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnSecurityGroupHeader.Size = New System.Drawing.Size(281, 41)
        Me.BtnSecurityGroupHeader.TabIndex = 27
        Me.BtnSecurityGroupHeader.Text = "مجموعه الآمان"
        Me.BtnSecurityGroupHeader.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnSecurityGroupHeader.UseVisualStyleBackColor = true
        '
        'PanelEmployees
        '
        Me.PanelEmployees.BackColor = System.Drawing.Color.Transparent
        Me.PanelEmployees.Controls.Add(Me.BtnSalaryGroups)
        Me.PanelEmployees.Controls.Add(Me.BtnAttendanceLeave)
        Me.PanelEmployees.Controls.Add(Me.Panel1)
        Me.PanelEmployees.Controls.Add(Me.Button3)
        Me.PanelEmployees.Controls.Add(Me.Panel20)
        Me.PanelEmployees.Controls.Add(Me.MenuDiscounts)
        Me.PanelEmployees.Controls.Add(Me.Panel4)
        Me.PanelEmployees.Controls.Add(Me.MenuRewards)
        Me.PanelEmployees.Controls.Add(Me.BtnTasks)
        Me.PanelEmployees.Controls.Add(Me.BtnVacations)
        Me.PanelEmployees.Controls.Add(Me.BtnAttendance)
        Me.PanelEmployees.Controls.Add(Me.BtnEmployees)
        Me.PanelEmployees.Controls.Add(Me.BtnJobs)
        Me.PanelEmployees.Controls.Add(Me.BtnDepartments)
        Me.PanelEmployees.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelEmployees.ForeColor = System.Drawing.Color.White
        Me.PanelEmployees.Location = New System.Drawing.Point(0, 0)
        Me.PanelEmployees.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelEmployees.Name = "PanelEmployees"
        Me.PanelEmployees.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.PanelEmployees.Size = New System.Drawing.Size(281, 838)
        Me.PanelEmployees.TabIndex = 48
        Me.PanelEmployees.Visible = false
        '
        'BtnSalaryGroups
        '
        Me.BtnSalaryGroups.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnSalaryGroups.BackgroundImage = CType(resources.GetObject("BtnSalaryGroups.BackgroundImage"),System.Drawing.Image)
        Me.BtnSalaryGroups.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSalaryGroups.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSalaryGroups.FlatAppearance.BorderSize = 0
        Me.BtnSalaryGroups.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSalaryGroups.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSalaryGroups.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSalaryGroups.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSalaryGroups.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSalaryGroups.ImageKey = "db_remove.png"
        Me.BtnSalaryGroups.Location = New System.Drawing.Point(0, 573)
        Me.BtnSalaryGroups.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSalaryGroups.Name = "BtnSalaryGroups"
        Me.BtnSalaryGroups.Size = New System.Drawing.Size(281, 32)
        Me.BtnSalaryGroups.TabIndex = 42
        Me.BtnSalaryGroups.Text = "بنود المرتبات"
        Me.BtnSalaryGroups.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnSalaryGroups.UseVisualStyleBackColor = false
        '
        'BtnAttendanceLeave
        '
        Me.BtnAttendanceLeave.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnAttendanceLeave.BackgroundImage = CType(resources.GetObject("BtnAttendanceLeave.BackgroundImage"),System.Drawing.Image)
        Me.BtnAttendanceLeave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnAttendanceLeave.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnAttendanceLeave.FlatAppearance.BorderSize = 0
        Me.BtnAttendanceLeave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnAttendanceLeave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnAttendanceLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAttendanceLeave.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnAttendanceLeave.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnAttendanceLeave.ImageKey = "db_remove.png"
        Me.BtnAttendanceLeave.Location = New System.Drawing.Point(0, 541)
        Me.BtnAttendanceLeave.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnAttendanceLeave.Name = "BtnAttendanceLeave"
        Me.BtnAttendanceLeave.Size = New System.Drawing.Size(281, 32)
        Me.BtnAttendanceLeave.TabIndex = 41
        Me.BtnAttendanceLeave.Text = "تعديل وقت الانصراف للموظفين"
        Me.BtnAttendanceLeave.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnAttendanceLeave.UseVisualStyleBackColor = false
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 467)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(281, 74)
        Me.Panel1.TabIndex = 40
        Me.Panel1.Visible = false
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Transparent
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"),System.Drawing.Image)
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Button4.Location = New System.Drawing.Point(0, 37)
        Me.Button4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(281, 37)
        Me.Button4.TabIndex = 16
        Me.Button4.Text = "بدلات الموظفين"
        Me.Button4.UseVisualStyleBackColor = false
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Transparent
        Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"),System.Drawing.Image)
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button5.Location = New System.Drawing.Point(0, 0)
        Me.Button5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(281, 37)
        Me.Button5.TabIndex = 15
        Me.Button5.Text = "بنود البدلات"
        Me.Button5.UseVisualStyleBackColor = false
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"),System.Drawing.Image)
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.ImageKey = "db_remove.png"
        Me.Button3.Location = New System.Drawing.Point(0, 435)
        Me.Button3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(281, 32)
        Me.Button3.TabIndex = 40
        Me.Button3.Text = "البدلات"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Button3.UseVisualStyleBackColor = false
        '
        'Panel20
        '
        Me.Panel20.Controls.Add(Me.BtnEmployeesDiscounts)
        Me.Panel20.Controls.Add(Me.BtnDiscountCatergories)
        Me.Panel20.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel20.Location = New System.Drawing.Point(0, 361)
        Me.Panel20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(281, 74)
        Me.Panel20.TabIndex = 39
        Me.Panel20.Visible = false
        '
        'BtnEmployeesDiscounts
        '
        Me.BtnEmployeesDiscounts.BackColor = System.Drawing.Color.Transparent
        Me.BtnEmployeesDiscounts.BackgroundImage = CType(resources.GetObject("BtnEmployeesDiscounts.BackgroundImage"),System.Drawing.Image)
        Me.BtnEmployeesDiscounts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnEmployeesDiscounts.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnEmployeesDiscounts.FlatAppearance.BorderSize = 0
        Me.BtnEmployeesDiscounts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnEmployeesDiscounts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnEmployeesDiscounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEmployeesDiscounts.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnEmployeesDiscounts.Location = New System.Drawing.Point(0, 37)
        Me.BtnEmployeesDiscounts.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnEmployeesDiscounts.Name = "BtnEmployeesDiscounts"
        Me.BtnEmployeesDiscounts.Size = New System.Drawing.Size(281, 37)
        Me.BtnEmployeesDiscounts.TabIndex = 16
        Me.BtnEmployeesDiscounts.Text = "خصومات الموظفيين"
        Me.BtnEmployeesDiscounts.UseVisualStyleBackColor = false
        '
        'BtnDiscountCatergories
        '
        Me.BtnDiscountCatergories.BackColor = System.Drawing.Color.Transparent
        Me.BtnDiscountCatergories.BackgroundImage = CType(resources.GetObject("BtnDiscountCatergories.BackgroundImage"),System.Drawing.Image)
        Me.BtnDiscountCatergories.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnDiscountCatergories.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnDiscountCatergories.FlatAppearance.BorderSize = 0
        Me.BtnDiscountCatergories.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnDiscountCatergories.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnDiscountCatergories.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnDiscountCatergories.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnDiscountCatergories.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnDiscountCatergories.Location = New System.Drawing.Point(0, 0)
        Me.BtnDiscountCatergories.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnDiscountCatergories.Name = "BtnDiscountCatergories"
        Me.BtnDiscountCatergories.Size = New System.Drawing.Size(281, 37)
        Me.BtnDiscountCatergories.TabIndex = 15
        Me.BtnDiscountCatergories.Text = "بنود الخصومات"
        Me.BtnDiscountCatergories.UseVisualStyleBackColor = false
        '
        'MenuDiscounts
        '
        Me.MenuDiscounts.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuDiscounts.BackgroundImage = CType(resources.GetObject("MenuDiscounts.BackgroundImage"),System.Drawing.Image)
        Me.MenuDiscounts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuDiscounts.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuDiscounts.FlatAppearance.BorderSize = 0
        Me.MenuDiscounts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuDiscounts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuDiscounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuDiscounts.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuDiscounts.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuDiscounts.ImageKey = "db_remove.png"
        Me.MenuDiscounts.ImageList = Me.ButtonsImages
        Me.MenuDiscounts.Location = New System.Drawing.Point(0, 329)
        Me.MenuDiscounts.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuDiscounts.Name = "MenuDiscounts"
        Me.MenuDiscounts.Size = New System.Drawing.Size(281, 32)
        Me.MenuDiscounts.TabIndex = 14
        Me.MenuDiscounts.Text = "الخصومات"
        Me.MenuDiscounts.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuDiscounts.UseVisualStyleBackColor = false
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.BtnEmpRewards)
        Me.Panel4.Controls.Add(Me.BtnRewardsCategories)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 258)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(281, 71)
        Me.Panel4.TabIndex = 35
        Me.Panel4.Visible = false
        '
        'BtnEmpRewards
        '
        Me.BtnEmpRewards.BackgroundImage = CType(resources.GetObject("BtnEmpRewards.BackgroundImage"),System.Drawing.Image)
        Me.BtnEmpRewards.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnEmpRewards.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnEmpRewards.FlatAppearance.BorderSize = 0
        Me.BtnEmpRewards.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnEmpRewards.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnEmpRewards.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEmpRewards.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnEmpRewards.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnEmpRewards.ImageKey = "banker.png"
        Me.BtnEmpRewards.ImageList = Me.ButtonsImages
        Me.BtnEmpRewards.Location = New System.Drawing.Point(0, 34)
        Me.BtnEmpRewards.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnEmpRewards.Name = "BtnEmpRewards"
        Me.BtnEmpRewards.Size = New System.Drawing.Size(281, 34)
        Me.BtnEmpRewards.TabIndex = 12
        Me.BtnEmpRewards.Text = "مكافئات الموظفين"
        Me.BtnEmpRewards.UseVisualStyleBackColor = true
        '
        'BtnRewardsCategories
        '
        Me.BtnRewardsCategories.BackgroundImage = CType(resources.GetObject("BtnRewardsCategories.BackgroundImage"),System.Drawing.Image)
        Me.BtnRewardsCategories.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRewardsCategories.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRewardsCategories.FlatAppearance.BorderSize = 0
        Me.BtnRewardsCategories.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRewardsCategories.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRewardsCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRewardsCategories.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRewardsCategories.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnRewardsCategories.ImageKey = "06.png"
        Me.BtnRewardsCategories.ImageList = Me.ButtonsImages
        Me.BtnRewardsCategories.Location = New System.Drawing.Point(0, 0)
        Me.BtnRewardsCategories.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRewardsCategories.Name = "BtnRewardsCategories"
        Me.BtnRewardsCategories.Size = New System.Drawing.Size(281, 34)
        Me.BtnRewardsCategories.TabIndex = 11
        Me.BtnRewardsCategories.Text = " بنود المكافئات"
        Me.BtnRewardsCategories.UseVisualStyleBackColor = true
        '
        'MenuRewards
        '
        Me.MenuRewards.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuRewards.BackgroundImage = CType(resources.GetObject("MenuRewards.BackgroundImage"),System.Drawing.Image)
        Me.MenuRewards.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuRewards.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuRewards.FlatAppearance.BorderSize = 0
        Me.MenuRewards.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuRewards.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuRewards.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuRewards.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuRewards.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuRewards.ImageKey = "Coins-icon.png"
        Me.MenuRewards.ImageList = Me.ButtonsImages
        Me.MenuRewards.Location = New System.Drawing.Point(0, 226)
        Me.MenuRewards.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuRewards.Name = "MenuRewards"
        Me.MenuRewards.Size = New System.Drawing.Size(281, 32)
        Me.MenuRewards.TabIndex = 10
        Me.MenuRewards.TabStop = false
        Me.MenuRewards.Text = "المكافئات"
        Me.MenuRewards.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuRewards.UseVisualStyleBackColor = false
        '
        'BtnTasks
        '
        Me.BtnTasks.BackgroundImage = CType(resources.GetObject("BtnTasks.BackgroundImage"),System.Drawing.Image)
        Me.BtnTasks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnTasks.DialogResult = System.Windows.Forms.DialogResult.No
        Me.BtnTasks.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnTasks.FlatAppearance.BorderSize = 0
        Me.BtnTasks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnTasks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnTasks.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnTasks.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnTasks.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnTasks.ImageKey = "Status-mail-task-icon.png"
        Me.BtnTasks.ImageList = Me.ButtonsImages
        Me.BtnTasks.Location = New System.Drawing.Point(0, 188)
        Me.BtnTasks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnTasks.Name = "BtnTasks"
        Me.BtnTasks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnTasks.Size = New System.Drawing.Size(281, 38)
        Me.BtnTasks.TabIndex = 6
        Me.BtnTasks.Text = " بيانات المهمات"
        Me.BtnTasks.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnTasks.UseVisualStyleBackColor = true
        '
        'BtnVacations
        '
        Me.BtnVacations.BackColor = System.Drawing.Color.Transparent
        Me.BtnVacations.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_4123
        Me.BtnVacations.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnVacations.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnVacations.FlatAppearance.BorderSize = 0
        Me.BtnVacations.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnVacations.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnVacations.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnVacations.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnVacations.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnVacations.ImageKey = "holidays.png"
        Me.BtnVacations.ImageList = Me.ButtonsImages
        Me.BtnVacations.Location = New System.Drawing.Point(0, 150)
        Me.BtnVacations.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnVacations.Name = "BtnVacations"
        Me.BtnVacations.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnVacations.Size = New System.Drawing.Size(281, 38)
        Me.BtnVacations.TabIndex = 1
        Me.BtnVacations.Text = "الأجازات"
        Me.BtnVacations.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnVacations.UseVisualStyleBackColor = false
        '
        'BtnAttendance
        '
        Me.BtnAttendance.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_4123
        Me.BtnAttendance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnAttendance.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnAttendance.FlatAppearance.BorderSize = 0
        Me.BtnAttendance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnAttendance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAttendance.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnAttendance.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnAttendance.Location = New System.Drawing.Point(0, 113)
        Me.BtnAttendance.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnAttendance.Name = "BtnAttendance"
        Me.BtnAttendance.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnAttendance.Size = New System.Drawing.Size(281, 37)
        Me.BtnAttendance.TabIndex = 5
        Me.BtnAttendance.Text = "الحضور والإنصراف"
        Me.BtnAttendance.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnAttendance.UseVisualStyleBackColor = true
        '
        'BtnEmployees
        '
        Me.BtnEmployees.BackColor = System.Drawing.Color.Transparent
        Me.BtnEmployees.BackgroundImage = CType(resources.GetObject("BtnEmployees.BackgroundImage"),System.Drawing.Image)
        Me.BtnEmployees.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnEmployees.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnEmployees.FlatAppearance.BorderSize = 0
        Me.BtnEmployees.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnEmployees.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnEmployees.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEmployees.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnEmployees.ForeColor = System.Drawing.Color.White
        Me.BtnEmployees.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnEmployees.ImageKey = "Manager.png"
        Me.BtnEmployees.ImageList = Me.ButtonsImages
        Me.BtnEmployees.Location = New System.Drawing.Point(0, 75)
        Me.BtnEmployees.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnEmployees.Name = "BtnEmployees"
        Me.BtnEmployees.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnEmployees.Size = New System.Drawing.Size(281, 38)
        Me.BtnEmployees.TabIndex = 4
        Me.BtnEmployees.Text = "بيانات الموظفيين "
        Me.BtnEmployees.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnEmployees.UseVisualStyleBackColor = false
        '
        'BtnJobs
        '
        Me.BtnJobs.BackgroundImage = CType(resources.GetObject("BtnJobs.BackgroundImage"),System.Drawing.Image)
        Me.BtnJobs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnJobs.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnJobs.FlatAppearance.BorderSize = 0
        Me.BtnJobs.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnJobs.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnJobs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnJobs.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnJobs.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnJobs.ImageIndex = 34
        Me.BtnJobs.ImageList = Me.ButtonsImages
        Me.BtnJobs.Location = New System.Drawing.Point(0, 37)
        Me.BtnJobs.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnJobs.Name = "BtnJobs"
        Me.BtnJobs.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnJobs.Size = New System.Drawing.Size(281, 38)
        Me.BtnJobs.TabIndex = 3
        Me.BtnJobs.Text = "المسمى الوظيفى"
        Me.BtnJobs.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnJobs.UseVisualStyleBackColor = true
        '
        'BtnDepartments
        '
        Me.BtnDepartments.BackgroundImage = CType(resources.GetObject("BtnDepartments.BackgroundImage"),System.Drawing.Image)
        Me.BtnDepartments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnDepartments.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnDepartments.FlatAppearance.BorderSize = 0
        Me.BtnDepartments.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnDepartments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnDepartments.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnDepartments.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnDepartments.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnDepartments.ImageKey = "Company.png"
        Me.BtnDepartments.ImageList = Me.ButtonsImages
        Me.BtnDepartments.Location = New System.Drawing.Point(0, 0)
        Me.BtnDepartments.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnDepartments.Name = "BtnDepartments"
        Me.BtnDepartments.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnDepartments.Size = New System.Drawing.Size(281, 37)
        Me.BtnDepartments.TabIndex = 2
        Me.BtnDepartments.Text = "بيانات الاداره "
        Me.BtnDepartments.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnDepartments.UseVisualStyleBackColor = true
        '
        'PanelReports
        '
        Me.PanelReports.AutoScroll = true
        Me.PanelReports.BackColor = System.Drawing.Color.Transparent
        Me.PanelReports.Controls.Add(Me.BtnPrintEmpCards)
        Me.PanelReports.Controls.Add(Me.BtnPrintBarcode)
        Me.PanelReports.Controls.Add(Me.BtnBackCard)
        Me.PanelReports.Controls.Add(Me.btnreportEmployees)
        Me.PanelReports.Controls.Add(Me.Panel8)
        Me.PanelReports.Controls.Add(Me.Button2)
        Me.PanelReports.Controls.Add(Me.BtnGymReports)
        Me.PanelReports.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelReports.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.PanelReports.ForeColor = System.Drawing.Color.White
        Me.PanelReports.Location = New System.Drawing.Point(0, 0)
        Me.PanelReports.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelReports.Name = "PanelReports"
        Me.PanelReports.Size = New System.Drawing.Size(281, 838)
        Me.PanelReports.TabIndex = 33
        Me.PanelReports.Visible = false
        '
        'BtnPrintEmpCards
        '
        Me.BtnPrintEmpCards.BackgroundImage = CType(resources.GetObject("BtnPrintEmpCards.BackgroundImage"),System.Drawing.Image)
        Me.BtnPrintEmpCards.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnPrintEmpCards.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPrintEmpCards.FlatAppearance.BorderSize = 0
        Me.BtnPrintEmpCards.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnPrintEmpCards.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnPrintEmpCards.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPrintEmpCards.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnPrintEmpCards.Location = New System.Drawing.Point(0, 820)
        Me.BtnPrintEmpCards.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnPrintEmpCards.Name = "BtnPrintEmpCards"
        Me.BtnPrintEmpCards.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnPrintEmpCards.Size = New System.Drawing.Size(260, 39)
        Me.BtnPrintEmpCards.TabIndex = 84
        Me.BtnPrintEmpCards.Text = "طباعة كروت الموظفين"
        Me.BtnPrintEmpCards.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnPrintEmpCards.UseVisualStyleBackColor = true
        '
        'BtnPrintBarcode
        '
        Me.BtnPrintBarcode.BackgroundImage = CType(resources.GetObject("BtnPrintBarcode.BackgroundImage"),System.Drawing.Image)
        Me.BtnPrintBarcode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnPrintBarcode.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPrintBarcode.FlatAppearance.BorderSize = 0
        Me.BtnPrintBarcode.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnPrintBarcode.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnPrintBarcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPrintBarcode.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnPrintBarcode.Location = New System.Drawing.Point(0, 781)
        Me.BtnPrintBarcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnPrintBarcode.Name = "BtnPrintBarcode"
        Me.BtnPrintBarcode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnPrintBarcode.Size = New System.Drawing.Size(260, 39)
        Me.BtnPrintBarcode.TabIndex = 81
        Me.BtnPrintBarcode.Text = "طباعة كروت العملاء"
        Me.BtnPrintBarcode.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnPrintBarcode.UseVisualStyleBackColor = true
        '
        'BtnBackCard
        '
        Me.BtnBackCard.BackgroundImage = CType(resources.GetObject("BtnBackCard.BackgroundImage"),System.Drawing.Image)
        Me.BtnBackCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnBackCard.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnBackCard.FlatAppearance.BorderSize = 0
        Me.BtnBackCard.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnBackCard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnBackCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnBackCard.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnBackCard.Location = New System.Drawing.Point(0, 742)
        Me.BtnBackCard.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnBackCard.Name = "BtnBackCard"
        Me.BtnBackCard.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnBackCard.Size = New System.Drawing.Size(260, 39)
        Me.BtnBackCard.TabIndex = 83
        Me.BtnBackCard.Text = "تقرير خلفية الكروت"
        Me.BtnBackCard.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnBackCard.UseVisualStyleBackColor = true
        '
        'btnreportEmployees
        '
        Me.btnreportEmployees.BackgroundImage = CType(resources.GetObject("btnreportEmployees.BackgroundImage"),System.Drawing.Image)
        Me.btnreportEmployees.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnreportEmployees.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnreportEmployees.FlatAppearance.BorderSize = 0
        Me.btnreportEmployees.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.btnreportEmployees.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.btnreportEmployees.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnreportEmployees.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.btnreportEmployees.Location = New System.Drawing.Point(0, 703)
        Me.btnreportEmployees.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnreportEmployees.Name = "btnreportEmployees"
        Me.btnreportEmployees.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnreportEmployees.Size = New System.Drawing.Size(260, 39)
        Me.btnreportEmployees.TabIndex = 85
        Me.btnreportEmployees.Text = "تقارير الموظفين"
        Me.btnreportEmployees.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.btnreportEmployees.UseVisualStyleBackColor = true
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.BtnRptAccountsBalance)
        Me.Panel8.Controls.Add(Me.BtnAnyAccount)
        Me.Panel8.Controls.Add(Me.BtnReportItemExpiration)
        Me.Panel8.Controls.Add(Me.BtnStockDetails)
        Me.Panel8.Controls.Add(Me.BtnGeneralBalance)
        Me.Panel8.Controls.Add(Me.BtnRptItemsUm)
        Me.Panel8.Controls.Add(Me.BtnRptStockValue)
        Me.Panel8.Controls.Add(Me.BtnRptUserLog)
        Me.Panel8.Controls.Add(Me.BtnRptInvLog)
        Me.Panel8.Controls.Add(Me.BtnRptDepItems)
        Me.Panel8.Controls.Add(Me.BtnRptBarcode)
        Me.Panel8.Controls.Add(Me.BtnRptSalesOrder)
        Me.Panel8.Controls.Add(Me.BtnRptCustomersReturns)
        Me.Panel8.Controls.Add(Me.BtnRptVendorReturns)
        Me.Panel8.Controls.Add(Me.BtnRptPurchaseOrder)
        Me.Panel8.Controls.Add(Me.BtnRptAdjustments)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel8.Location = New System.Drawing.Point(0, 78)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(260, 625)
        Me.Panel8.TabIndex = 0
        Me.Panel8.Visible = false
        '
        'BtnRptAccountsBalance
        '
        Me.BtnRptAccountsBalance.BackgroundImage = CType(resources.GetObject("BtnRptAccountsBalance.BackgroundImage"),System.Drawing.Image)
        Me.BtnRptAccountsBalance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptAccountsBalance.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptAccountsBalance.FlatAppearance.BorderSize = 0
        Me.BtnRptAccountsBalance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptAccountsBalance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptAccountsBalance.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptAccountsBalance.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptAccountsBalance.Location = New System.Drawing.Point(0, 585)
        Me.BtnRptAccountsBalance.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptAccountsBalance.Name = "BtnRptAccountsBalance"
        Me.BtnRptAccountsBalance.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptAccountsBalance.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptAccountsBalance.TabIndex = 94
        Me.BtnRptAccountsBalance.Text = "تقرير أرصدة الحسابات"
        Me.BtnRptAccountsBalance.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptAccountsBalance.UseVisualStyleBackColor = true
        '
        'BtnAnyAccount
        '
        Me.BtnAnyAccount.BackgroundImage = CType(resources.GetObject("BtnAnyAccount.BackgroundImage"),System.Drawing.Image)
        Me.BtnAnyAccount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnAnyAccount.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnAnyAccount.FlatAppearance.BorderSize = 0
        Me.BtnAnyAccount.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnAnyAccount.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnAnyAccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAnyAccount.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnAnyAccount.Location = New System.Drawing.Point(0, 546)
        Me.BtnAnyAccount.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnAnyAccount.Name = "BtnAnyAccount"
        Me.BtnAnyAccount.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnAnyAccount.Size = New System.Drawing.Size(260, 39)
        Me.BtnAnyAccount.TabIndex = 93
        Me.BtnAnyAccount.Text = "كشف حساب عام"
        Me.BtnAnyAccount.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnAnyAccount.UseVisualStyleBackColor = true
        '
        'BtnReportItemExpiration
        '
        Me.BtnReportItemExpiration.BackgroundImage = CType(resources.GetObject("BtnReportItemExpiration.BackgroundImage"),System.Drawing.Image)
        Me.BtnReportItemExpiration.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnReportItemExpiration.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnReportItemExpiration.FlatAppearance.BorderSize = 0
        Me.BtnReportItemExpiration.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnReportItemExpiration.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnReportItemExpiration.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnReportItemExpiration.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnReportItemExpiration.Location = New System.Drawing.Point(0, 507)
        Me.BtnReportItemExpiration.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnReportItemExpiration.Name = "BtnReportItemExpiration"
        Me.BtnReportItemExpiration.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnReportItemExpiration.Size = New System.Drawing.Size(260, 39)
        Me.BtnReportItemExpiration.TabIndex = 92
        Me.BtnReportItemExpiration.Text = "تواريخ صلاحية الأصناف"
        Me.BtnReportItemExpiration.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnReportItemExpiration.UseVisualStyleBackColor = true
        '
        'BtnStockDetails
        '
        Me.BtnStockDetails.BackgroundImage = CType(resources.GetObject("BtnStockDetails.BackgroundImage"),System.Drawing.Image)
        Me.BtnStockDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnStockDetails.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnStockDetails.FlatAppearance.BorderSize = 0
        Me.BtnStockDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnStockDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnStockDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnStockDetails.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnStockDetails.Location = New System.Drawing.Point(0, 468)
        Me.BtnStockDetails.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnStockDetails.Name = "BtnStockDetails"
        Me.BtnStockDetails.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnStockDetails.Size = New System.Drawing.Size(260, 39)
        Me.BtnStockDetails.TabIndex = 91
        Me.BtnStockDetails.Text = "التقرير التفصيلي لأرصدة المخزن"
        Me.BtnStockDetails.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnStockDetails.UseVisualStyleBackColor = true
        '
        'BtnGeneralBalance
        '
        Me.BtnGeneralBalance.BackgroundImage = CType(resources.GetObject("BtnGeneralBalance.BackgroundImage"),System.Drawing.Image)
        Me.BtnGeneralBalance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnGeneralBalance.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnGeneralBalance.FlatAppearance.BorderSize = 0
        Me.BtnGeneralBalance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnGeneralBalance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnGeneralBalance.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnGeneralBalance.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnGeneralBalance.Location = New System.Drawing.Point(0, 429)
        Me.BtnGeneralBalance.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnGeneralBalance.Name = "BtnGeneralBalance"
        Me.BtnGeneralBalance.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnGeneralBalance.Size = New System.Drawing.Size(260, 39)
        Me.BtnGeneralBalance.TabIndex = 90
        Me.BtnGeneralBalance.Text = "التقرير العام لأرصدة المخزن"
        Me.BtnGeneralBalance.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnGeneralBalance.UseVisualStyleBackColor = true
        '
        'BtnRptItemsUm
        '
        Me.BtnRptItemsUm.BackgroundImage = CType(resources.GetObject("BtnRptItemsUm.BackgroundImage"),System.Drawing.Image)
        Me.BtnRptItemsUm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptItemsUm.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptItemsUm.FlatAppearance.BorderSize = 0
        Me.BtnRptItemsUm.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptItemsUm.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptItemsUm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptItemsUm.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptItemsUm.Location = New System.Drawing.Point(0, 390)
        Me.BtnRptItemsUm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptItemsUm.Name = "BtnRptItemsUm"
        Me.BtnRptItemsUm.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptItemsUm.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptItemsUm.TabIndex = 89
        Me.BtnRptItemsUm.Text = "تقرير وحدات القياس"
        Me.BtnRptItemsUm.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptItemsUm.UseVisualStyleBackColor = true
        '
        'BtnRptStockValue
        '
        Me.BtnRptStockValue.BackgroundImage = CType(resources.GetObject("BtnRptStockValue.BackgroundImage"),System.Drawing.Image)
        Me.BtnRptStockValue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptStockValue.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptStockValue.FlatAppearance.BorderSize = 0
        Me.BtnRptStockValue.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptStockValue.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptStockValue.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptStockValue.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptStockValue.Location = New System.Drawing.Point(0, 351)
        Me.BtnRptStockValue.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptStockValue.Name = "BtnRptStockValue"
        Me.BtnRptStockValue.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptStockValue.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptStockValue.TabIndex = 88
        Me.BtnRptStockValue.Text = "تقييم المخزن"
        Me.BtnRptStockValue.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptStockValue.UseVisualStyleBackColor = true
        '
        'BtnRptUserLog
        '
        Me.BtnRptUserLog.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptUserLog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptUserLog.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptUserLog.FlatAppearance.BorderSize = 0
        Me.BtnRptUserLog.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptUserLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptUserLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptUserLog.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptUserLog.Location = New System.Drawing.Point(0, 312)
        Me.BtnRptUserLog.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptUserLog.Name = "BtnRptUserLog"
        Me.BtnRptUserLog.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptUserLog.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptUserLog.TabIndex = 87
        Me.BtnRptUserLog.Text = "تقرير حركة المستخدمين"
        Me.BtnRptUserLog.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptUserLog.UseVisualStyleBackColor = true
        '
        'BtnRptInvLog
        '
        Me.BtnRptInvLog.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptInvLog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptInvLog.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptInvLog.FlatAppearance.BorderSize = 0
        Me.BtnRptInvLog.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptInvLog.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptInvLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptInvLog.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptInvLog.Location = New System.Drawing.Point(0, 273)
        Me.BtnRptInvLog.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptInvLog.Name = "BtnRptInvLog"
        Me.BtnRptInvLog.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptInvLog.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptInvLog.TabIndex = 86
        Me.BtnRptInvLog.Text = "تقرير حركة المخزن"
        Me.BtnRptInvLog.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptInvLog.UseVisualStyleBackColor = true
        '
        'BtnRptDepItems
        '
        Me.BtnRptDepItems.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptDepItems.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptDepItems.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptDepItems.FlatAppearance.BorderSize = 0
        Me.BtnRptDepItems.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptDepItems.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptDepItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptDepItems.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptDepItems.Location = New System.Drawing.Point(0, 234)
        Me.BtnRptDepItems.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptDepItems.Name = "BtnRptDepItems"
        Me.BtnRptDepItems.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptDepItems.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptDepItems.TabIndex = 85
        Me.BtnRptDepItems.Text = "اذونات اهلاك الأصناف"
        Me.BtnRptDepItems.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptDepItems.UseVisualStyleBackColor = true
        '
        'BtnRptBarcode
        '
        Me.BtnRptBarcode.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptBarcode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptBarcode.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptBarcode.FlatAppearance.BorderSize = 0
        Me.BtnRptBarcode.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptBarcode.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptBarcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptBarcode.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptBarcode.Location = New System.Drawing.Point(0, 195)
        Me.BtnRptBarcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptBarcode.Name = "BtnRptBarcode"
        Me.BtnRptBarcode.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptBarcode.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptBarcode.TabIndex = 84
        Me.BtnRptBarcode.Text = "طباعة باركود الأصناف"
        Me.BtnRptBarcode.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptBarcode.UseVisualStyleBackColor = true
        Me.BtnRptBarcode.Visible = false
        '
        'BtnRptSalesOrder
        '
        Me.BtnRptSalesOrder.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptSalesOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptSalesOrder.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptSalesOrder.FlatAppearance.BorderSize = 0
        Me.BtnRptSalesOrder.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptSalesOrder.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptSalesOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptSalesOrder.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptSalesOrder.Location = New System.Drawing.Point(0, 156)
        Me.BtnRptSalesOrder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptSalesOrder.Name = "BtnRptSalesOrder"
        Me.BtnRptSalesOrder.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptSalesOrder.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptSalesOrder.TabIndex = 83
        Me.BtnRptSalesOrder.Text = "فواتير المبيعات"
        Me.BtnRptSalesOrder.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptSalesOrder.UseVisualStyleBackColor = true
        '
        'BtnRptCustomersReturns
        '
        Me.BtnRptCustomersReturns.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptCustomersReturns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptCustomersReturns.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptCustomersReturns.FlatAppearance.BorderSize = 0
        Me.BtnRptCustomersReturns.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptCustomersReturns.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptCustomersReturns.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptCustomersReturns.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptCustomersReturns.Location = New System.Drawing.Point(0, 117)
        Me.BtnRptCustomersReturns.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptCustomersReturns.Name = "BtnRptCustomersReturns"
        Me.BtnRptCustomersReturns.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptCustomersReturns.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptCustomersReturns.TabIndex = 82
        Me.BtnRptCustomersReturns.Text = "اذونات ارتجاع العملاء"
        Me.BtnRptCustomersReturns.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptCustomersReturns.UseVisualStyleBackColor = true
        '
        'BtnRptVendorReturns
        '
        Me.BtnRptVendorReturns.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptVendorReturns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptVendorReturns.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptVendorReturns.FlatAppearance.BorderSize = 0
        Me.BtnRptVendorReturns.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptVendorReturns.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptVendorReturns.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptVendorReturns.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptVendorReturns.Location = New System.Drawing.Point(0, 78)
        Me.BtnRptVendorReturns.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptVendorReturns.Name = "BtnRptVendorReturns"
        Me.BtnRptVendorReturns.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptVendorReturns.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptVendorReturns.TabIndex = 81
        Me.BtnRptVendorReturns.Text = "اذونات ارتجاع الموردين"
        Me.BtnRptVendorReturns.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptVendorReturns.UseVisualStyleBackColor = true
        '
        'BtnRptPurchaseOrder
        '
        Me.BtnRptPurchaseOrder.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptPurchaseOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptPurchaseOrder.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptPurchaseOrder.FlatAppearance.BorderSize = 0
        Me.BtnRptPurchaseOrder.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptPurchaseOrder.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptPurchaseOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptPurchaseOrder.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptPurchaseOrder.Location = New System.Drawing.Point(0, 39)
        Me.BtnRptPurchaseOrder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptPurchaseOrder.Name = "BtnRptPurchaseOrder"
        Me.BtnRptPurchaseOrder.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptPurchaseOrder.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptPurchaseOrder.TabIndex = 80
        Me.BtnRptPurchaseOrder.Text = "فواتير المشتريات"
        Me.BtnRptPurchaseOrder.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnRptPurchaseOrder.UseVisualStyleBackColor = true
        '
        'BtnRptAdjustments
        '
        Me.BtnRptAdjustments.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnRptAdjustments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnRptAdjustments.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnRptAdjustments.FlatAppearance.BorderSize = 0
        Me.BtnRptAdjustments.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnRptAdjustments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnRptAdjustments.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnRptAdjustments.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnRptAdjustments.Location = New System.Drawing.Point(0, 0)
        Me.BtnRptAdjustments.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnRptAdjustments.Name = "BtnRptAdjustments"
        Me.BtnRptAdjustments.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRptAdjustments.Size = New System.Drawing.Size(260, 39)
        Me.BtnRptAdjustments.TabIndex = 79
        Me.BtnRptAdjustments.Text = "اذونات التحويل"
        Me.BtnRptAdjustments.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnRptAdjustments.UseVisualStyleBackColor = true
        '
        'Button2
        '
        Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"),System.Drawing.Image)
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Button2.Location = New System.Drawing.Point(0, 39)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Button2.Size = New System.Drawing.Size(260, 39)
        Me.Button2.TabIndex = 86
        Me.Button2.Text = "تقارير الحسابات والمخازن"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Button2.UseVisualStyleBackColor = true
        '
        'BtnGymReports
        '
        Me.BtnGymReports.BackgroundImage = CType(resources.GetObject("BtnGymReports.BackgroundImage"),System.Drawing.Image)
        Me.BtnGymReports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnGymReports.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnGymReports.FlatAppearance.BorderSize = 0
        Me.BtnGymReports.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnGymReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnGymReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnGymReports.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnGymReports.Location = New System.Drawing.Point(0, 0)
        Me.BtnGymReports.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnGymReports.Name = "BtnGymReports"
        Me.BtnGymReports.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnGymReports.Size = New System.Drawing.Size(260, 39)
        Me.BtnGymReports.TabIndex = 51
        Me.BtnGymReports.Text = "تقارير الجيم"
        Me.BtnGymReports.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.BtnGymReports.UseVisualStyleBackColor = true
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.Controls.Add(Me.BtnActivatePanel)
        Me.Panel5.Controls.Add(Me.PanelReports)
        Me.Panel5.Controls.Add(Me.PanelAccounting)
        Me.Panel5.Controls.Add(Me.PanelStatistics)
        Me.Panel5.Controls.Add(Me.PanelCustomer)
        Me.Panel5.Controls.Add(Me.PanelEmployees)
        Me.Panel5.Controls.Add(Me.PanelSettings)
        Me.Panel5.Controls.Add(Me.PanelStock)
        Me.Panel5.Controls.Add(Me.PanelSecurity)
        Me.Panel5.Controls.Add(Me.PanelVendor)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel5.Location = New System.Drawing.Point(1217, 75)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Panel5.Size = New System.Drawing.Size(281, 838)
        Me.Panel5.TabIndex = 93
        '
        'BtnActivatePanel
        '
        Me.BtnActivatePanel.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.BtnActivatePanel.Dock = System.Windows.Forms.DockStyle.Left
        Me.BtnActivatePanel.Location = New System.Drawing.Point(0, 0)
        Me.BtnActivatePanel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnActivatePanel.Name = "BtnActivatePanel"
        Me.BtnActivatePanel.Size = New System.Drawing.Size(23, 838)
        Me.BtnActivatePanel.TabIndex = 48
        Me.BtnActivatePanel.Text = "<>"
        Me.BtnActivatePanel.UseVisualStyleBackColor = false
        '
        'PanelAccounting
        '
        Me.PanelAccounting.AutoScroll = true
        Me.PanelAccounting.BackColor = System.Drawing.Color.Transparent
        Me.PanelAccounting.Controls.Add(Me.RptIncome)
        Me.PanelAccounting.Controls.Add(Me.BtnPaySalary)
        Me.PanelAccounting.Controls.Add(Me.BtnPayAllSalaries)
        Me.PanelAccounting.Controls.Add(Me.MenuEmpAccounts)
        Me.PanelAccounting.Controls.Add(Me.MenuDepPro)
        Me.PanelAccounting.Controls.Add(Me.MenuBalanceSheet)
        Me.PanelAccounting.Controls.Add(Me.MenuBalanceBook)
        Me.PanelAccounting.Controls.Add(Me.MenuMasterRecord)
        Me.PanelAccounting.Controls.Add(Me.Panel19)
        Me.PanelAccounting.Controls.Add(Me.Button18)
        Me.PanelAccounting.Controls.Add(Me.Panel18)
        Me.PanelAccounting.Controls.Add(Me.Banks)
        Me.PanelAccounting.Controls.Add(Me.Panel17)
        Me.PanelAccounting.Controls.Add(Me.Cheques)
        Me.PanelAccounting.Controls.Add(Me.Panel16)
        Me.PanelAccounting.Controls.Add(Me.constraint)
        Me.PanelAccounting.Controls.Add(Me.MenuDailyProNames)
        Me.PanelAccounting.Controls.Add(Me.MenuIncomeDetailsByPeriod)
        Me.PanelAccounting.Controls.Add(Me.Panel10)
        Me.PanelAccounting.Controls.Add(Me.MenuExpenses)
        Me.PanelAccounting.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelAccounting.ForeColor = System.Drawing.Color.White
        Me.PanelAccounting.Location = New System.Drawing.Point(0, 0)
        Me.PanelAccounting.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelAccounting.Name = "PanelAccounting"
        Me.PanelAccounting.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.PanelAccounting.Size = New System.Drawing.Size(281, 838)
        Me.PanelAccounting.TabIndex = 97
        Me.PanelAccounting.Visible = false
        '
        'RptIncome
        '
        Me.RptIncome.BackgroundImage = CType(resources.GetObject("RptIncome.BackgroundImage"),System.Drawing.Image)
        Me.RptIncome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.RptIncome.DialogResult = System.Windows.Forms.DialogResult.No
        Me.RptIncome.Dock = System.Windows.Forms.DockStyle.Top
        Me.RptIncome.FlatAppearance.BorderSize = 0
        Me.RptIncome.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.RptIncome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.RptIncome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RptIncome.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.RptIncome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.RptIncome.ImageKey = "27-Edit Text.png"
        Me.RptIncome.Location = New System.Drawing.Point(0, 892)
        Me.RptIncome.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.RptIncome.Name = "RptIncome"
        Me.RptIncome.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RptIncome.Size = New System.Drawing.Size(260, 38)
        Me.RptIncome.TabIndex = 103
        Me.RptIncome.Text = "التقرير اليومي"
        Me.RptIncome.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.RptIncome.UseVisualStyleBackColor = true
        '
        'BtnPaySalary
        '
        Me.BtnPaySalary.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnPaySalary.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnPaySalary.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPaySalary.FlatAppearance.BorderSize = 0
        Me.BtnPaySalary.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnPaySalary.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnPaySalary.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPaySalary.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnPaySalary.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnPaySalary.ImageKey = "payment-icon.png"
        Me.BtnPaySalary.ImageList = Me.ButtonsImages
        Me.BtnPaySalary.Location = New System.Drawing.Point(0, 854)
        Me.BtnPaySalary.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnPaySalary.Name = "BtnPaySalary"
        Me.BtnPaySalary.Size = New System.Drawing.Size(260, 38)
        Me.BtnPaySalary.TabIndex = 102
        Me.BtnPaySalary.Text = "اعتماد مرتب موظف"
        Me.BtnPaySalary.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnPaySalary.UseVisualStyleBackColor = true
        Me.BtnPaySalary.Visible = false
        '
        'BtnPayAllSalaries
        '
        Me.BtnPayAllSalaries.BackgroundImage = Global.GYM.My.Resources.Resources._end
        Me.BtnPayAllSalaries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnPayAllSalaries.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPayAllSalaries.FlatAppearance.BorderSize = 0
        Me.BtnPayAllSalaries.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnPayAllSalaries.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnPayAllSalaries.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPayAllSalaries.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnPayAllSalaries.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnPayAllSalaries.ImageKey = "payment-icon.png"
        Me.BtnPayAllSalaries.ImageList = Me.ButtonsImages
        Me.BtnPayAllSalaries.Location = New System.Drawing.Point(0, 816)
        Me.BtnPayAllSalaries.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnPayAllSalaries.Name = "BtnPayAllSalaries"
        Me.BtnPayAllSalaries.Size = New System.Drawing.Size(260, 38)
        Me.BtnPayAllSalaries.TabIndex = 101
        Me.BtnPayAllSalaries.Text = "سداد المرتبات"
        Me.BtnPayAllSalaries.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BtnPayAllSalaries.UseVisualStyleBackColor = true
        Me.BtnPayAllSalaries.Visible = false
        '
        'MenuEmpAccounts
        '
        Me.MenuEmpAccounts.BackgroundImage = CType(resources.GetObject("MenuEmpAccounts.BackgroundImage"),System.Drawing.Image)
        Me.MenuEmpAccounts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuEmpAccounts.DialogResult = System.Windows.Forms.DialogResult.No
        Me.MenuEmpAccounts.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuEmpAccounts.FlatAppearance.BorderSize = 0
        Me.MenuEmpAccounts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuEmpAccounts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuEmpAccounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuEmpAccounts.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuEmpAccounts.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.MenuEmpAccounts.ImageKey = "Groups-Meeting-Dark-icon.png"
        Me.MenuEmpAccounts.ImageList = Me.ButtonsImages
        Me.MenuEmpAccounts.Location = New System.Drawing.Point(0, 778)
        Me.MenuEmpAccounts.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuEmpAccounts.Name = "MenuEmpAccounts"
        Me.MenuEmpAccounts.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.MenuEmpAccounts.Size = New System.Drawing.Size(260, 38)
        Me.MenuEmpAccounts.TabIndex = 100
        Me.MenuEmpAccounts.Text = "حسابات شئون العامليين"
        Me.MenuEmpAccounts.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.MenuEmpAccounts.UseVisualStyleBackColor = true
        '
        'MenuDepPro
        '
        Me.MenuDepPro.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuDepPro.BackgroundImage = CType(resources.GetObject("MenuDepPro.BackgroundImage"),System.Drawing.Image)
        Me.MenuDepPro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuDepPro.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuDepPro.FlatAppearance.BorderSize = 0
        Me.MenuDepPro.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuDepPro.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuDepPro.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuDepPro.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuDepPro.Location = New System.Drawing.Point(0, 744)
        Me.MenuDepPro.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuDepPro.Name = "MenuDepPro"
        Me.MenuDepPro.Size = New System.Drawing.Size(260, 34)
        Me.MenuDepPro.TabIndex = 62
        Me.MenuDepPro.Text = "اهلاك الاصول الثابته"
        Me.MenuDepPro.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuDepPro.UseVisualStyleBackColor = false
        '
        'MenuBalanceSheet
        '
        Me.MenuBalanceSheet.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuBalanceSheet.BackgroundImage = CType(resources.GetObject("MenuBalanceSheet.BackgroundImage"),System.Drawing.Image)
        Me.MenuBalanceSheet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuBalanceSheet.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuBalanceSheet.FlatAppearance.BorderSize = 0
        Me.MenuBalanceSheet.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuBalanceSheet.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuBalanceSheet.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuBalanceSheet.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuBalanceSheet.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuBalanceSheet.ImageKey = "Sheet-of-paper-icon.png"
        Me.MenuBalanceSheet.ImageList = Me.ButtonsImages
        Me.MenuBalanceSheet.Location = New System.Drawing.Point(0, 710)
        Me.MenuBalanceSheet.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuBalanceSheet.Name = "MenuBalanceSheet"
        Me.MenuBalanceSheet.Size = New System.Drawing.Size(260, 34)
        Me.MenuBalanceSheet.TabIndex = 60
        Me.MenuBalanceSheet.Text = "الميزانيه العموميه "
        Me.MenuBalanceSheet.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuBalanceSheet.UseVisualStyleBackColor = false
        '
        'MenuBalanceBook
        '
        Me.MenuBalanceBook.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuBalanceBook.BackgroundImage = CType(resources.GetObject("MenuBalanceBook.BackgroundImage"),System.Drawing.Image)
        Me.MenuBalanceBook.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuBalanceBook.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuBalanceBook.FlatAppearance.BorderSize = 0
        Me.MenuBalanceBook.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuBalanceBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuBalanceBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuBalanceBook.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuBalanceBook.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuBalanceBook.ImageKey = "Balance-icon.png"
        Me.MenuBalanceBook.ImageList = Me.ButtonsImages
        Me.MenuBalanceBook.Location = New System.Drawing.Point(0, 676)
        Me.MenuBalanceBook.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuBalanceBook.Name = "MenuBalanceBook"
        Me.MenuBalanceBook.Size = New System.Drawing.Size(260, 34)
        Me.MenuBalanceBook.TabIndex = 59
        Me.MenuBalanceBook.Text = "ميزان المراجعه"
        Me.MenuBalanceBook.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuBalanceBook.UseVisualStyleBackColor = false
        '
        'MenuMasterRecord
        '
        Me.MenuMasterRecord.BackgroundImage = CType(resources.GetObject("MenuMasterRecord.BackgroundImage"),System.Drawing.Image)
        Me.MenuMasterRecord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuMasterRecord.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuMasterRecord.FlatAppearance.BorderSize = 0
        Me.MenuMasterRecord.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuMasterRecord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuMasterRecord.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuMasterRecord.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuMasterRecord.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuMasterRecord.ImageKey = "client_account_template.png"
        Me.MenuMasterRecord.ImageList = Me.ButtonsImages
        Me.MenuMasterRecord.Location = New System.Drawing.Point(0, 642)
        Me.MenuMasterRecord.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuMasterRecord.Name = "MenuMasterRecord"
        Me.MenuMasterRecord.Size = New System.Drawing.Size(260, 34)
        Me.MenuMasterRecord.TabIndex = 61
        Me.MenuMasterRecord.Text = "حساب الاستاذ"
        Me.MenuMasterRecord.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuMasterRecord.UseVisualStyleBackColor = true
        '
        'Panel19
        '
        Me.Panel19.Controls.Add(Me.MenuMoneyReceivable)
        Me.Panel19.Controls.Add(Me.MenuMoneyPayments)
        Me.Panel19.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel19.Location = New System.Drawing.Point(0, 572)
        Me.Panel19.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(260, 70)
        Me.Panel19.TabIndex = 58
        Me.Panel19.Visible = false
        '
        'MenuMoneyReceivable
        '
        Me.MenuMoneyReceivable.BackColor = System.Drawing.Color.Transparent
        Me.MenuMoneyReceivable.BackgroundImage = CType(resources.GetObject("MenuMoneyReceivable.BackgroundImage"),System.Drawing.Image)
        Me.MenuMoneyReceivable.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuMoneyReceivable.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuMoneyReceivable.FlatAppearance.BorderSize = 0
        Me.MenuMoneyReceivable.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuMoneyReceivable.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuMoneyReceivable.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuMoneyReceivable.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuMoneyReceivable.Location = New System.Drawing.Point(0, 34)
        Me.MenuMoneyReceivable.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuMoneyReceivable.Name = "MenuMoneyReceivable"
        Me.MenuMoneyReceivable.Size = New System.Drawing.Size(260, 36)
        Me.MenuMoneyReceivable.TabIndex = 24
        Me.MenuMoneyReceivable.Text = "إذن استلام"
        Me.MenuMoneyReceivable.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuMoneyReceivable.UseVisualStyleBackColor = false
        '
        'MenuMoneyPayments
        '
        Me.MenuMoneyPayments.BackColor = System.Drawing.Color.Transparent
        Me.MenuMoneyPayments.BackgroundImage = CType(resources.GetObject("MenuMoneyPayments.BackgroundImage"),System.Drawing.Image)
        Me.MenuMoneyPayments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuMoneyPayments.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuMoneyPayments.FlatAppearance.BorderSize = 0
        Me.MenuMoneyPayments.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuMoneyPayments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuMoneyPayments.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuMoneyPayments.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuMoneyPayments.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuMoneyPayments.Location = New System.Drawing.Point(0, 0)
        Me.MenuMoneyPayments.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuMoneyPayments.Name = "MenuMoneyPayments"
        Me.MenuMoneyPayments.Size = New System.Drawing.Size(260, 34)
        Me.MenuMoneyPayments.TabIndex = 25
        Me.MenuMoneyPayments.Text = "إذن دفع"
        Me.MenuMoneyPayments.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuMoneyPayments.UseVisualStyleBackColor = false
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Button18.BackgroundImage = CType(resources.GetObject("Button18.BackgroundImage"),System.Drawing.Image)
        Me.Button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button18.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button18.FlatAppearance.BorderSize = 0
        Me.Button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button18.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Button18.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button18.ImageKey = "Proposal-512.png"
        Me.Button18.ImageList = Me.ButtonsImages
        Me.Button18.Location = New System.Drawing.Point(0, 538)
        Me.Button18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(260, 34)
        Me.Button18.TabIndex = 57
        Me.Button18.Text = "إذونات الدفع"
        Me.Button18.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Button18.UseVisualStyleBackColor = false
        '
        'Panel18
        '
        Me.Panel18.Controls.Add(Me.MenuBanks)
        Me.Panel18.Controls.Add(Me.MenuBanksAccounts)
        Me.Panel18.Controls.Add(Me.BtnVisa)
        Me.Panel18.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel18.Location = New System.Drawing.Point(0, 432)
        Me.Panel18.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(260, 106)
        Me.Panel18.TabIndex = 56
        Me.Panel18.Visible = false
        '
        'MenuBanks
        '
        Me.MenuBanks.BackColor = System.Drawing.Color.Transparent
        Me.MenuBanks.BackgroundImage = CType(resources.GetObject("MenuBanks.BackgroundImage"),System.Drawing.Image)
        Me.MenuBanks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuBanks.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuBanks.FlatAppearance.BorderSize = 0
        Me.MenuBanks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuBanks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuBanks.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuBanks.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuBanks.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuBanks.ImageKey = "bank.png"
        Me.MenuBanks.ImageList = Me.ButtonsImages
        Me.MenuBanks.Location = New System.Drawing.Point(0, 68)
        Me.MenuBanks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuBanks.Name = "MenuBanks"
        Me.MenuBanks.Size = New System.Drawing.Size(260, 37)
        Me.MenuBanks.TabIndex = 8
        Me.MenuBanks.Text = "بيانات البنوك"
        Me.MenuBanks.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuBanks.UseVisualStyleBackColor = false
        '
        'MenuBanksAccounts
        '
        Me.MenuBanksAccounts.BackColor = System.Drawing.Color.Transparent
        Me.MenuBanksAccounts.BackgroundImage = CType(resources.GetObject("MenuBanksAccounts.BackgroundImage"),System.Drawing.Image)
        Me.MenuBanksAccounts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuBanksAccounts.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuBanksAccounts.FlatAppearance.BorderSize = 0
        Me.MenuBanksAccounts.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuBanksAccounts.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuBanksAccounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuBanksAccounts.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuBanksAccounts.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuBanksAccounts.ImageKey = "Bank_account.png"
        Me.MenuBanksAccounts.ImageList = Me.ButtonsImages
        Me.MenuBanksAccounts.Location = New System.Drawing.Point(0, 34)
        Me.MenuBanksAccounts.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuBanksAccounts.Name = "MenuBanksAccounts"
        Me.MenuBanksAccounts.Size = New System.Drawing.Size(260, 34)
        Me.MenuBanksAccounts.TabIndex = 27
        Me.MenuBanksAccounts.Text = "حسابات البنوك"
        Me.MenuBanksAccounts.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuBanksAccounts.UseVisualStyleBackColor = false
        '
        'BtnVisa
        '
        Me.BtnVisa.BackColor = System.Drawing.Color.Transparent
        Me.BtnVisa.BackgroundImage = CType(resources.GetObject("BtnVisa.BackgroundImage"),System.Drawing.Image)
        Me.BtnVisa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnVisa.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnVisa.FlatAppearance.BorderSize = 0
        Me.BtnVisa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnVisa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnVisa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnVisa.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnVisa.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.BtnVisa.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnVisa.ImageKey = "payment-card.png"
        Me.BtnVisa.ImageList = Me.ButtonsImages
        Me.BtnVisa.Location = New System.Drawing.Point(0, 0)
        Me.BtnVisa.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnVisa.Name = "BtnVisa"
        Me.BtnVisa.Size = New System.Drawing.Size(260, 34)
        Me.BtnVisa.TabIndex = 26
        Me.BtnVisa.Text = "بيانات الفيزا"
        Me.BtnVisa.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnVisa.UseVisualStyleBackColor = false
        '
        'Banks
        '
        Me.Banks.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Banks.BackgroundImage = CType(resources.GetObject("Banks.BackgroundImage"),System.Drawing.Image)
        Me.Banks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Banks.Dock = System.Windows.Forms.DockStyle.Top
        Me.Banks.FlatAppearance.BorderSize = 0
        Me.Banks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Banks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Banks.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Banks.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Banks.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Banks.ImageKey = "Transaction_3D-512.png"
        Me.Banks.ImageList = Me.ButtonsImages
        Me.Banks.Location = New System.Drawing.Point(0, 398)
        Me.Banks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Banks.Name = "Banks"
        Me.Banks.Size = New System.Drawing.Size(260, 34)
        Me.Banks.TabIndex = 55
        Me.Banks.Text = "تعاملات البنوك"
        Me.Banks.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Banks.UseVisualStyleBackColor = false
        '
        'Panel17
        '
        Me.Panel17.Controls.Add(Me.MenuCheques)
        Me.Panel17.Controls.Add(Me.MenuChequeStatus)
        Me.Panel17.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel17.Location = New System.Drawing.Point(0, 329)
        Me.Panel17.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(260, 69)
        Me.Panel17.TabIndex = 54
        Me.Panel17.Visible = false
        '
        'MenuCheques
        '
        Me.MenuCheques.BackColor = System.Drawing.Color.Transparent
        Me.MenuCheques.BackgroundImage = CType(resources.GetObject("MenuCheques.BackgroundImage"),System.Drawing.Image)
        Me.MenuCheques.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuCheques.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuCheques.FlatAppearance.BorderSize = 0
        Me.MenuCheques.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuCheques.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuCheques.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuCheques.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuCheques.Location = New System.Drawing.Point(0, 34)
        Me.MenuCheques.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuCheques.Name = "MenuCheques"
        Me.MenuCheques.Size = New System.Drawing.Size(260, 34)
        Me.MenuCheques.TabIndex = 16
        Me.MenuCheques.Text = "شيكات"
        Me.MenuCheques.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuCheques.UseVisualStyleBackColor = false
        '
        'MenuChequeStatus
        '
        Me.MenuChequeStatus.BackColor = System.Drawing.Color.Transparent
        Me.MenuChequeStatus.BackgroundImage = CType(resources.GetObject("MenuChequeStatus.BackgroundImage"),System.Drawing.Image)
        Me.MenuChequeStatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuChequeStatus.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuChequeStatus.FlatAppearance.BorderSize = 0
        Me.MenuChequeStatus.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuChequeStatus.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuChequeStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuChequeStatus.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuChequeStatus.Location = New System.Drawing.Point(0, 0)
        Me.MenuChequeStatus.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuChequeStatus.Name = "MenuChequeStatus"
        Me.MenuChequeStatus.Size = New System.Drawing.Size(260, 34)
        Me.MenuChequeStatus.TabIndex = 17
        Me.MenuChequeStatus.Text = "تفاصيل شيكات"
        Me.MenuChequeStatus.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuChequeStatus.UseVisualStyleBackColor = false
        '
        'Cheques
        '
        Me.Cheques.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Cheques.BackgroundImage = CType(resources.GetObject("Cheques.BackgroundImage"),System.Drawing.Image)
        Me.Cheques.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Cheques.Dock = System.Windows.Forms.DockStyle.Top
        Me.Cheques.FlatAppearance.BorderSize = 0
        Me.Cheques.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Cheques.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Cheques.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cheques.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Cheques.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Cheques.ImageKey = "cheque-icon.png"
        Me.Cheques.ImageList = Me.ButtonsImages
        Me.Cheques.Location = New System.Drawing.Point(0, 292)
        Me.Cheques.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Cheques.Name = "Cheques"
        Me.Cheques.Size = New System.Drawing.Size(260, 37)
        Me.Cheques.TabIndex = 53
        Me.Cheques.Text = "الشيكات"
        Me.Cheques.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.Cheques.UseVisualStyleBackColor = false
        '
        'Panel16
        '
        Me.Panel16.Controls.Add(Me.MenuDailyProcedures)
        Me.Panel16.Controls.Add(Me.MenuNewProcedureTran)
        Me.Panel16.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel16.Location = New System.Drawing.Point(0, 226)
        Me.Panel16.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(260, 66)
        Me.Panel16.TabIndex = 52
        Me.Panel16.Visible = false
        '
        'MenuDailyProcedures
        '
        Me.MenuDailyProcedures.BackColor = System.Drawing.Color.Transparent
        Me.MenuDailyProcedures.BackgroundImage = CType(resources.GetObject("MenuDailyProcedures.BackgroundImage"),System.Drawing.Image)
        Me.MenuDailyProcedures.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuDailyProcedures.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuDailyProcedures.FlatAppearance.BorderSize = 0
        Me.MenuDailyProcedures.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuDailyProcedures.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuDailyProcedures.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuDailyProcedures.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuDailyProcedures.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuDailyProcedures.Location = New System.Drawing.Point(0, 34)
        Me.MenuDailyProcedures.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuDailyProcedures.Name = "MenuDailyProcedures"
        Me.MenuDailyProcedures.Size = New System.Drawing.Size(260, 34)
        Me.MenuDailyProcedures.TabIndex = 18
        Me.MenuDailyProcedures.Text = "دفتر قيود اليوميه"
        Me.MenuDailyProcedures.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuDailyProcedures.UseVisualStyleBackColor = false
        '
        'MenuNewProcedureTran
        '
        Me.MenuNewProcedureTran.BackColor = System.Drawing.Color.Transparent
        Me.MenuNewProcedureTran.BackgroundImage = CType(resources.GetObject("MenuNewProcedureTran.BackgroundImage"),System.Drawing.Image)
        Me.MenuNewProcedureTran.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuNewProcedureTran.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuNewProcedureTran.FlatAppearance.BorderSize = 0
        Me.MenuNewProcedureTran.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuNewProcedureTran.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuNewProcedureTran.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuNewProcedureTran.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuNewProcedureTran.Location = New System.Drawing.Point(0, 0)
        Me.MenuNewProcedureTran.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuNewProcedureTran.Name = "MenuNewProcedureTran"
        Me.MenuNewProcedureTran.Size = New System.Drawing.Size(260, 34)
        Me.MenuNewProcedureTran.TabIndex = 15
        Me.MenuNewProcedureTran.Text = "ادخال قيد جديد"
        Me.MenuNewProcedureTran.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuNewProcedureTran.UseVisualStyleBackColor = false
        '
        'constraint
        '
        Me.constraint.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.constraint.BackgroundImage = CType(resources.GetObject("constraint.BackgroundImage"),System.Drawing.Image)
        Me.constraint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.constraint.Dock = System.Windows.Forms.DockStyle.Top
        Me.constraint.FlatAppearance.BorderSize = 0
        Me.constraint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.constraint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.constraint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.constraint.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.constraint.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.constraint.ImageKey = "Properties.png"
        Me.constraint.ImageList = Me.ButtonsImages
        Me.constraint.Location = New System.Drawing.Point(0, 187)
        Me.constraint.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.constraint.Name = "constraint"
        Me.constraint.Size = New System.Drawing.Size(260, 39)
        Me.constraint.TabIndex = 51
        Me.constraint.Text = "القيود"
        Me.constraint.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.constraint.UseVisualStyleBackColor = false
        '
        'MenuDailyProNames
        '
        Me.MenuDailyProNames.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_4123
        Me.MenuDailyProNames.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuDailyProNames.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuDailyProNames.FlatAppearance.BorderSize = 0
        Me.MenuDailyProNames.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuDailyProNames.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuDailyProNames.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuDailyProNames.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuDailyProNames.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuDailyProNames.ImageKey = "user_accounts_help.png"
        Me.MenuDailyProNames.ImageList = Me.ButtonsImages
        Me.MenuDailyProNames.Location = New System.Drawing.Point(0, 145)
        Me.MenuDailyProNames.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuDailyProNames.Name = "MenuDailyProNames"
        Me.MenuDailyProNames.Size = New System.Drawing.Size(260, 42)
        Me.MenuDailyProNames.TabIndex = 50
        Me.MenuDailyProNames.Text = " اسماء الحسابات"
        Me.MenuDailyProNames.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuDailyProNames.UseVisualStyleBackColor = true
        '
        'MenuIncomeDetailsByPeriod
        '
        Me.MenuIncomeDetailsByPeriod.BackgroundImage = CType(resources.GetObject("MenuIncomeDetailsByPeriod.BackgroundImage"),System.Drawing.Image)
        Me.MenuIncomeDetailsByPeriod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuIncomeDetailsByPeriod.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuIncomeDetailsByPeriod.FlatAppearance.BorderSize = 0
        Me.MenuIncomeDetailsByPeriod.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuIncomeDetailsByPeriod.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuIncomeDetailsByPeriod.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuIncomeDetailsByPeriod.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuIncomeDetailsByPeriod.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuIncomeDetailsByPeriod.ImageKey = "income-icon.png"
        Me.MenuIncomeDetailsByPeriod.ImageList = Me.ButtonsImages
        Me.MenuIncomeDetailsByPeriod.Location = New System.Drawing.Point(0, 106)
        Me.MenuIncomeDetailsByPeriod.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuIncomeDetailsByPeriod.Name = "MenuIncomeDetailsByPeriod"
        Me.MenuIncomeDetailsByPeriod.Size = New System.Drawing.Size(260, 39)
        Me.MenuIncomeDetailsByPeriod.TabIndex = 49
        Me.MenuIncomeDetailsByPeriod.Text = "قائمه الدخل التفصيليه"
        Me.MenuIncomeDetailsByPeriod.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuIncomeDetailsByPeriod.UseVisualStyleBackColor = true
        '
        'Panel10
        '
        Me.Panel10.Controls.Add(Me.MenuExpensesOther)
        Me.Panel10.Controls.Add(Me.MenuExpensesHeader)
        Me.Panel10.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel10.Location = New System.Drawing.Point(0, 38)
        Me.Panel10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(260, 68)
        Me.Panel10.TabIndex = 48
        Me.Panel10.Visible = false
        '
        'MenuExpensesOther
        '
        Me.MenuExpensesOther.BackgroundImage = CType(resources.GetObject("MenuExpensesOther.BackgroundImage"),System.Drawing.Image)
        Me.MenuExpensesOther.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuExpensesOther.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuExpensesOther.FlatAppearance.BorderSize = 0
        Me.MenuExpensesOther.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuExpensesOther.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuExpensesOther.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuExpensesOther.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuExpensesOther.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuExpensesOther.Location = New System.Drawing.Point(0, 36)
        Me.MenuExpensesOther.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuExpensesOther.Name = "MenuExpensesOther"
        Me.MenuExpensesOther.Size = New System.Drawing.Size(260, 33)
        Me.MenuExpensesOther.TabIndex = 7
        Me.MenuExpensesOther.Text = "مصاريف عامه"
        Me.MenuExpensesOther.UseVisualStyleBackColor = true
        '
        'MenuExpensesHeader
        '
        Me.MenuExpensesHeader.BackColor = System.Drawing.Color.Transparent
        Me.MenuExpensesHeader.BackgroundImage = CType(resources.GetObject("MenuExpensesHeader.BackgroundImage"),System.Drawing.Image)
        Me.MenuExpensesHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuExpensesHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuExpensesHeader.FlatAppearance.BorderSize = 0
        Me.MenuExpensesHeader.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuExpensesHeader.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuExpensesHeader.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuExpensesHeader.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuExpensesHeader.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuExpensesHeader.Location = New System.Drawing.Point(0, 0)
        Me.MenuExpensesHeader.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuExpensesHeader.Name = "MenuExpensesHeader"
        Me.MenuExpensesHeader.Size = New System.Drawing.Size(260, 36)
        Me.MenuExpensesHeader.TabIndex = 0
        Me.MenuExpensesHeader.Text = "بنود المصروفات"
        Me.MenuExpensesHeader.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.MenuExpensesHeader.UseVisualStyleBackColor = false
        '
        'MenuExpenses
        '
        Me.MenuExpenses.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.MenuExpenses.BackgroundImage = CType(resources.GetObject("MenuExpenses.BackgroundImage"),System.Drawing.Image)
        Me.MenuExpenses.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MenuExpenses.Dock = System.Windows.Forms.DockStyle.Top
        Me.MenuExpenses.FlatAppearance.BorderSize = 0
        Me.MenuExpenses.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.MenuExpenses.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.MenuExpenses.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.MenuExpenses.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.MenuExpenses.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.MenuExpenses.ImageKey = "Money.png"
        Me.MenuExpenses.ImageList = Me.ButtonsImages
        Me.MenuExpenses.Location = New System.Drawing.Point(0, 0)
        Me.MenuExpenses.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MenuExpenses.Name = "MenuExpenses"
        Me.MenuExpenses.Size = New System.Drawing.Size(260, 38)
        Me.MenuExpenses.TabIndex = 47
        Me.MenuExpenses.Text = "المصروفات"
        Me.MenuExpenses.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.MenuExpenses.UseVisualStyleBackColor = false
        '
        'PanelStatistics
        '
        Me.PanelStatistics.BackColor = System.Drawing.Color.Transparent
        Me.PanelStatistics.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelStatistics.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.PanelStatistics.ForeColor = System.Drawing.Color.White
        Me.PanelStatistics.Location = New System.Drawing.Point(0, 0)
        Me.PanelStatistics.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelStatistics.Name = "PanelStatistics"
        Me.PanelStatistics.Size = New System.Drawing.Size(281, 838)
        Me.PanelStatistics.TabIndex = 98
        Me.PanelStatistics.Visible = false
        '
        'PanelCustomer
        '
        Me.PanelCustomer.BackColor = System.Drawing.Color.Transparent
        Me.PanelCustomer.Controls.Add(Me.BntSubscReturn)
        Me.PanelCustomer.Controls.Add(Me.BtnCompanies)
        Me.PanelCustomer.Controls.Add(Me.BtnCustOrderEvaluation)
        Me.PanelCustomer.Controls.Add(Me.BtnCustEvaluation)
        Me.PanelCustomer.Controls.Add(Me.BtnEvaluationCategory)
        Me.PanelCustomer.Controls.Add(Me.BtnSpecialSub)
        Me.PanelCustomer.Controls.Add(Me.BtnSpecialSubCa)
        Me.PanelCustomer.Controls.Add(Me.BtnCustomersAttendance)
        Me.PanelCustomer.Controls.Add(Me.BtnSubDaily)
        Me.PanelCustomer.Controls.Add(Me.BtnCustomerSubscription)
        Me.PanelCustomer.Controls.Add(Me.BtnSubscriptions)
        Me.PanelCustomer.Controls.Add(Me.BtnSubscripionsCategories)
        Me.PanelCustomer.Controls.Add(Me.BtnCustomerReturns)
        Me.PanelCustomer.Controls.Add(Me.BtnSalesOrder)
        Me.PanelCustomer.Controls.Add(Me.BtnCustomers)
        Me.PanelCustomer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelCustomer.ForeColor = System.Drawing.Color.White
        Me.PanelCustomer.Location = New System.Drawing.Point(0, 0)
        Me.PanelCustomer.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelCustomer.Name = "PanelCustomer"
        Me.PanelCustomer.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.PanelCustomer.Size = New System.Drawing.Size(281, 838)
        Me.PanelCustomer.TabIndex = 95
        Me.PanelCustomer.Visible = false
        '
        'BntSubscReturn
        '
        Me.BntSubscReturn.BackgroundImage = CType(resources.GetObject("BntSubscReturn.BackgroundImage"),System.Drawing.Image)
        Me.BntSubscReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BntSubscReturn.Dock = System.Windows.Forms.DockStyle.Top
        Me.BntSubscReturn.FlatAppearance.BorderSize = 0
        Me.BntSubscReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BntSubscReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BntSubscReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BntSubscReturn.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BntSubscReturn.Location = New System.Drawing.Point(0, 547)
        Me.BntSubscReturn.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BntSubscReturn.Name = "BntSubscReturn"
        Me.BntSubscReturn.Size = New System.Drawing.Size(281, 39)
        Me.BntSubscReturn.TabIndex = 114
        Me.BntSubscReturn.Text = "ارجاع الاشتراكات"
        Me.BntSubscReturn.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BntSubscReturn.UseVisualStyleBackColor = true
        '
        'BtnCompanies
        '
        Me.BtnCompanies.BackgroundImage = CType(resources.GetObject("BtnCompanies.BackgroundImage"),System.Drawing.Image)
        Me.BtnCompanies.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCompanies.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCompanies.FlatAppearance.BorderSize = 0
        Me.BtnCompanies.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCompanies.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCompanies.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCompanies.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCompanies.Location = New System.Drawing.Point(0, 508)
        Me.BtnCompanies.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCompanies.Name = "BtnCompanies"
        Me.BtnCompanies.Size = New System.Drawing.Size(281, 39)
        Me.BtnCompanies.TabIndex = 113
        Me.BtnCompanies.Text = "بيانات الجهات/المؤسسات"
        Me.BtnCompanies.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCompanies.UseVisualStyleBackColor = true
        '
        'BtnCustOrderEvaluation
        '
        Me.BtnCustOrderEvaluation.BackgroundImage = CType(resources.GetObject("BtnCustOrderEvaluation.BackgroundImage"),System.Drawing.Image)
        Me.BtnCustOrderEvaluation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCustOrderEvaluation.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCustOrderEvaluation.FlatAppearance.BorderSize = 0
        Me.BtnCustOrderEvaluation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCustOrderEvaluation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCustOrderEvaluation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCustOrderEvaluation.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCustOrderEvaluation.Location = New System.Drawing.Point(0, 469)
        Me.BtnCustOrderEvaluation.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCustOrderEvaluation.Name = "BtnCustOrderEvaluation"
        Me.BtnCustOrderEvaluation.Size = New System.Drawing.Size(281, 39)
        Me.BtnCustOrderEvaluation.TabIndex = 112
        Me.BtnCustOrderEvaluation.Text = "تقييمات العملاء"
        Me.BtnCustOrderEvaluation.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCustOrderEvaluation.UseVisualStyleBackColor = true
        '
        'BtnCustEvaluation
        '
        Me.BtnCustEvaluation.BackgroundImage = CType(resources.GetObject("BtnCustEvaluation.BackgroundImage"),System.Drawing.Image)
        Me.BtnCustEvaluation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCustEvaluation.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCustEvaluation.FlatAppearance.BorderSize = 0
        Me.BtnCustEvaluation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCustEvaluation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCustEvaluation.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCustEvaluation.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCustEvaluation.Location = New System.Drawing.Point(0, 430)
        Me.BtnCustEvaluation.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCustEvaluation.Name = "BtnCustEvaluation"
        Me.BtnCustEvaluation.Size = New System.Drawing.Size(281, 39)
        Me.BtnCustEvaluation.TabIndex = 111
        Me.BtnCustEvaluation.Text = "تفاصيل التقييمات"
        Me.BtnCustEvaluation.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCustEvaluation.UseVisualStyleBackColor = true
        '
        'BtnEvaluationCategory
        '
        Me.BtnEvaluationCategory.BackgroundImage = CType(resources.GetObject("BtnEvaluationCategory.BackgroundImage"),System.Drawing.Image)
        Me.BtnEvaluationCategory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnEvaluationCategory.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnEvaluationCategory.FlatAppearance.BorderSize = 0
        Me.BtnEvaluationCategory.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnEvaluationCategory.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnEvaluationCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEvaluationCategory.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnEvaluationCategory.Location = New System.Drawing.Point(0, 391)
        Me.BtnEvaluationCategory.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnEvaluationCategory.Name = "BtnEvaluationCategory"
        Me.BtnEvaluationCategory.Size = New System.Drawing.Size(281, 39)
        Me.BtnEvaluationCategory.TabIndex = 110
        Me.BtnEvaluationCategory.Text = "بنود التقييمات"
        Me.BtnEvaluationCategory.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnEvaluationCategory.UseVisualStyleBackColor = true
        '
        'BtnSpecialSub
        '
        Me.BtnSpecialSub.BackgroundImage = CType(resources.GetObject("BtnSpecialSub.BackgroundImage"),System.Drawing.Image)
        Me.BtnSpecialSub.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSpecialSub.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSpecialSub.FlatAppearance.BorderSize = 0
        Me.BtnSpecialSub.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSpecialSub.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSpecialSub.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSpecialSub.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSpecialSub.Location = New System.Drawing.Point(0, 352)
        Me.BtnSpecialSub.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSpecialSub.Name = "BtnSpecialSub"
        Me.BtnSpecialSub.Size = New System.Drawing.Size(281, 39)
        Me.BtnSpecialSub.TabIndex = 109
        Me.BtnSpecialSub.Text = "حجز الجلسات الخاصه"
        Me.BtnSpecialSub.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnSpecialSub.UseVisualStyleBackColor = true
        '
        'BtnSpecialSubCa
        '
        Me.BtnSpecialSubCa.BackgroundImage = CType(resources.GetObject("BtnSpecialSubCa.BackgroundImage"),System.Drawing.Image)
        Me.BtnSpecialSubCa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSpecialSubCa.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSpecialSubCa.FlatAppearance.BorderSize = 0
        Me.BtnSpecialSubCa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSpecialSubCa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSpecialSubCa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSpecialSubCa.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSpecialSubCa.Location = New System.Drawing.Point(0, 313)
        Me.BtnSpecialSubCa.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSpecialSubCa.Name = "BtnSpecialSubCa"
        Me.BtnSpecialSubCa.Size = New System.Drawing.Size(281, 39)
        Me.BtnSpecialSubCa.TabIndex = 106
        Me.BtnSpecialSubCa.Text = "بنود الجلسات الخاصه"
        Me.BtnSpecialSubCa.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnSpecialSubCa.UseVisualStyleBackColor = true
        '
        'BtnCustomersAttendance
        '
        Me.BtnCustomersAttendance.BackgroundImage = CType(resources.GetObject("BtnCustomersAttendance.BackgroundImage"),System.Drawing.Image)
        Me.BtnCustomersAttendance.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCustomersAttendance.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCustomersAttendance.FlatAppearance.BorderSize = 0
        Me.BtnCustomersAttendance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomersAttendance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomersAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCustomersAttendance.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCustomersAttendance.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCustomersAttendance.ImageKey = "Mimetypes-text-directory-icon.png"
        Me.BtnCustomersAttendance.Location = New System.Drawing.Point(0, 274)
        Me.BtnCustomersAttendance.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCustomersAttendance.Name = "BtnCustomersAttendance"
        Me.BtnCustomersAttendance.Size = New System.Drawing.Size(281, 39)
        Me.BtnCustomersAttendance.TabIndex = 102
        Me.BtnCustomersAttendance.Text = "تسجيل حضور العملاء"
        Me.BtnCustomersAttendance.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCustomersAttendance.UseVisualStyleBackColor = true
        '
        'BtnSubDaily
        '
        Me.BtnSubDaily.BackgroundImage = CType(resources.GetObject("BtnSubDaily.BackgroundImage"),System.Drawing.Image)
        Me.BtnSubDaily.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSubDaily.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSubDaily.FlatAppearance.BorderSize = 0
        Me.BtnSubDaily.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSubDaily.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSubDaily.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSubDaily.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSubDaily.Location = New System.Drawing.Point(0, 235)
        Me.BtnSubDaily.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSubDaily.Name = "BtnSubDaily"
        Me.BtnSubDaily.Size = New System.Drawing.Size(281, 39)
        Me.BtnSubDaily.TabIndex = 29
        Me.BtnSubDaily.Text = "الاشتراكات و الخدمات اليوميه"
        Me.BtnSubDaily.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnSubDaily.UseVisualStyleBackColor = true
        '
        'BtnCustomerSubscription
        '
        Me.BtnCustomerSubscription.BackgroundImage = CType(resources.GetObject("BtnCustomerSubscription.BackgroundImage"),System.Drawing.Image)
        Me.BtnCustomerSubscription.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCustomerSubscription.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCustomerSubscription.FlatAppearance.BorderSize = 0
        Me.BtnCustomerSubscription.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomerSubscription.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomerSubscription.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCustomerSubscription.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCustomerSubscription.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCustomerSubscription.ImageKey = "Mimetypes-text-directory-icon.png"
        Me.BtnCustomerSubscription.ImageList = Me.ButtonsImages
        Me.BtnCustomerSubscription.Location = New System.Drawing.Point(0, 196)
        Me.BtnCustomerSubscription.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCustomerSubscription.Name = "BtnCustomerSubscription"
        Me.BtnCustomerSubscription.Size = New System.Drawing.Size(281, 39)
        Me.BtnCustomerSubscription.TabIndex = 28
        Me.BtnCustomerSubscription.Text = "حجز اشتراك"
        Me.BtnCustomerSubscription.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCustomerSubscription.UseVisualStyleBackColor = true
        '
        'BtnSubscriptions
        '
        Me.BtnSubscriptions.BackgroundImage = CType(resources.GetObject("BtnSubscriptions.BackgroundImage"),System.Drawing.Image)
        Me.BtnSubscriptions.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSubscriptions.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSubscriptions.FlatAppearance.BorderSize = 0
        Me.BtnSubscriptions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSubscriptions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSubscriptions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSubscriptions.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSubscriptions.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSubscriptions.ImageKey = "Program-Group-icon.png"
        Me.BtnSubscriptions.ImageList = Me.ButtonsImages
        Me.BtnSubscriptions.Location = New System.Drawing.Point(0, 157)
        Me.BtnSubscriptions.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSubscriptions.Name = "BtnSubscriptions"
        Me.BtnSubscriptions.Size = New System.Drawing.Size(281, 39)
        Me.BtnSubscriptions.TabIndex = 101
        Me.BtnSubscriptions.Text = "تفاصيل الاشتراكات و الخدمات"
        Me.BtnSubscriptions.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnSubscriptions.UseVisualStyleBackColor = true
        '
        'BtnSubscripionsCategories
        '
        Me.BtnSubscripionsCategories.BackgroundImage = CType(resources.GetObject("BtnSubscripionsCategories.BackgroundImage"),System.Drawing.Image)
        Me.BtnSubscripionsCategories.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSubscripionsCategories.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSubscripionsCategories.FlatAppearance.BorderSize = 0
        Me.BtnSubscripionsCategories.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSubscripionsCategories.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSubscripionsCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSubscripionsCategories.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSubscripionsCategories.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSubscripionsCategories.ImageKey = "It-Infrastructure-Active-directory-icon.png"
        Me.BtnSubscripionsCategories.ImageList = Me.ButtonsImages
        Me.BtnSubscripionsCategories.Location = New System.Drawing.Point(0, 119)
        Me.BtnSubscripionsCategories.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSubscripionsCategories.Name = "BtnSubscripionsCategories"
        Me.BtnSubscripionsCategories.Size = New System.Drawing.Size(281, 38)
        Me.BtnSubscripionsCategories.TabIndex = 100
        Me.BtnSubscripionsCategories.Text = "نوع الاشتراك"
        Me.BtnSubscripionsCategories.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnSubscripionsCategories.UseVisualStyleBackColor = true
        '
        'BtnCustomerReturns
        '
        Me.BtnCustomerReturns.BackgroundImage = CType(resources.GetObject("BtnCustomerReturns.BackgroundImage"),System.Drawing.Image)
        Me.BtnCustomerReturns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCustomerReturns.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCustomerReturns.FlatAppearance.BorderSize = 0
        Me.BtnCustomerReturns.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomerReturns.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomerReturns.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCustomerReturns.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCustomerReturns.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCustomerReturns.ImageKey = "network_reload.png"
        Me.BtnCustomerReturns.ImageList = Me.ButtonsImages
        Me.BtnCustomerReturns.Location = New System.Drawing.Point(0, 80)
        Me.BtnCustomerReturns.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCustomerReturns.Name = "BtnCustomerReturns"
        Me.BtnCustomerReturns.Size = New System.Drawing.Size(281, 39)
        Me.BtnCustomerReturns.TabIndex = 27
        Me.BtnCustomerReturns.Text = "مرتجع العملاء"
        Me.BtnCustomerReturns.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCustomerReturns.UseVisualStyleBackColor = true
        '
        'BtnSalesOrder
        '
        Me.BtnSalesOrder.BackgroundImage = CType(resources.GetObject("BtnSalesOrder.BackgroundImage"),System.Drawing.Image)
        Me.BtnSalesOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSalesOrder.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnSalesOrder.FlatAppearance.BorderSize = 0
        Me.BtnSalesOrder.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnSalesOrder.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnSalesOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnSalesOrder.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSalesOrder.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSalesOrder.ImageKey = "invoice.png"
        Me.BtnSalesOrder.ImageList = Me.ButtonsImages
        Me.BtnSalesOrder.Location = New System.Drawing.Point(0, 42)
        Me.BtnSalesOrder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnSalesOrder.Name = "BtnSalesOrder"
        Me.BtnSalesOrder.Size = New System.Drawing.Size(281, 38)
        Me.BtnSalesOrder.TabIndex = 25
        Me.BtnSalesOrder.Text = "فواتير المبيعات"
        Me.BtnSalesOrder.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnSalesOrder.UseVisualStyleBackColor = true
        '
        'BtnCustomers
        '
        Me.BtnCustomers.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_4123
        Me.BtnCustomers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCustomers.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCustomers.FlatAppearance.BorderSize = 0
        Me.BtnCustomers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCustomers.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCustomers.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCustomers.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCustomers.ImageKey = "Customer_Male_Light.png"
        Me.BtnCustomers.ImageList = Me.ButtonsImages
        Me.BtnCustomers.Location = New System.Drawing.Point(0, 0)
        Me.BtnCustomers.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCustomers.Name = "BtnCustomers"
        Me.BtnCustomers.Size = New System.Drawing.Size(281, 42)
        Me.BtnCustomers.TabIndex = 24
        Me.BtnCustomers.Text = "بيانات العملاء"
        Me.BtnCustomers.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCustomers.UseVisualStyleBackColor = true
        '
        'PanelStock
        '
        Me.PanelStock.BackColor = System.Drawing.Color.Transparent
        Me.PanelStock.Controls.Add(Me.BtnAdjustments)
        Me.PanelStock.Controls.Add(Me.BtnCheckDetails)
        Me.PanelStock.Controls.Add(Me.BtnCheckHeader)
        Me.PanelStock.Controls.Add(Me.BtnItemsOut)
        Me.PanelStock.Controls.Add(Me.BtnStocks)
        Me.PanelStock.Controls.Add(Me.BtnCategories)
        Me.PanelStock.Controls.Add(Me.BtnItemsStocks)
        Me.PanelStock.Controls.Add(Me.BtnUmDetails)
        Me.PanelStock.Controls.Add(Me.BtnUmMaster)
        Me.PanelStock.Controls.Add(Me.BtnCorporations)
        Me.PanelStock.Controls.Add(Me.BtnItems)
        Me.PanelStock.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelStock.ForeColor = System.Drawing.Color.White
        Me.PanelStock.Location = New System.Drawing.Point(0, 0)
        Me.PanelStock.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelStock.Name = "PanelStock"
        Me.PanelStock.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.PanelStock.Size = New System.Drawing.Size(281, 838)
        Me.PanelStock.TabIndex = 95
        Me.PanelStock.Visible = false
        '
        'BtnAdjustments
        '
        Me.BtnAdjustments.BackgroundImage = CType(resources.GetObject("BtnAdjustments.BackgroundImage"),System.Drawing.Image)
        Me.BtnAdjustments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnAdjustments.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnAdjustments.FlatAppearance.BorderSize = 0
        Me.BtnAdjustments.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnAdjustments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnAdjustments.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAdjustments.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnAdjustments.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnAdjustments.ImageKey = "stock_folder-move.png"
        Me.BtnAdjustments.ImageList = Me.ButtonsImages
        Me.BtnAdjustments.Location = New System.Drawing.Point(0, 340)
        Me.BtnAdjustments.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnAdjustments.Name = "BtnAdjustments"
        Me.BtnAdjustments.Size = New System.Drawing.Size(281, 34)
        Me.BtnAdjustments.TabIndex = 18
        Me.BtnAdjustments.Text = "أذونات التحويل"
        Me.BtnAdjustments.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnAdjustments.UseVisualStyleBackColor = true
        '
        'BtnCheckDetails
        '
        Me.BtnCheckDetails.BackgroundImage = CType(resources.GetObject("BtnCheckDetails.BackgroundImage"),System.Drawing.Image)
        Me.BtnCheckDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCheckDetails.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCheckDetails.FlatAppearance.BorderSize = 0
        Me.BtnCheckDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCheckDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCheckDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCheckDetails.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCheckDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCheckDetails.ImageKey = "stock_task.png"
        Me.BtnCheckDetails.ImageList = Me.ButtonsImages
        Me.BtnCheckDetails.Location = New System.Drawing.Point(0, 306)
        Me.BtnCheckDetails.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCheckDetails.Name = "BtnCheckDetails"
        Me.BtnCheckDetails.Size = New System.Drawing.Size(281, 34)
        Me.BtnCheckDetails.TabIndex = 17
        Me.BtnCheckDetails.Text = "تفاصيل جرد الاصناف"
        Me.BtnCheckDetails.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCheckDetails.UseVisualStyleBackColor = true
        '
        'BtnCheckHeader
        '
        Me.BtnCheckHeader.BackgroundImage = CType(resources.GetObject("BtnCheckHeader.BackgroundImage"),System.Drawing.Image)
        Me.BtnCheckHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCheckHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCheckHeader.FlatAppearance.BorderSize = 0
        Me.BtnCheckHeader.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCheckHeader.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCheckHeader.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCheckHeader.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCheckHeader.ImageAlign = System.Drawing.ContentAlignment.BottomRight
        Me.BtnCheckHeader.ImageKey = "Document-Add-icon.png"
        Me.BtnCheckHeader.ImageList = Me.ButtonsImages
        Me.BtnCheckHeader.Location = New System.Drawing.Point(0, 272)
        Me.BtnCheckHeader.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCheckHeader.Name = "BtnCheckHeader"
        Me.BtnCheckHeader.Size = New System.Drawing.Size(281, 34)
        Me.BtnCheckHeader.TabIndex = 16
        Me.BtnCheckHeader.Text = "جرد الاصناف"
        Me.BtnCheckHeader.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCheckHeader.UseVisualStyleBackColor = true
        '
        'BtnItemsOut
        '
        Me.BtnItemsOut.BackgroundImage = CType(resources.GetObject("BtnItemsOut.BackgroundImage"),System.Drawing.Image)
        Me.BtnItemsOut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnItemsOut.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnItemsOut.FlatAppearance.BorderSize = 0
        Me.BtnItemsOut.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnItemsOut.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnItemsOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnItemsOut.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnItemsOut.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnItemsOut.ImageKey = "Panneau-destroy.png"
        Me.BtnItemsOut.ImageList = Me.ButtonsImages
        Me.BtnItemsOut.Location = New System.Drawing.Point(0, 238)
        Me.BtnItemsOut.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnItemsOut.Name = "BtnItemsOut"
        Me.BtnItemsOut.Size = New System.Drawing.Size(281, 34)
        Me.BtnItemsOut.TabIndex = 15
        Me.BtnItemsOut.Text = "اهلاك الاصناف"
        Me.BtnItemsOut.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnItemsOut.UseVisualStyleBackColor = true
        '
        'BtnStocks
        '
        Me.BtnStocks.BackColor = System.Drawing.Color.Transparent
        Me.BtnStocks.BackgroundImage = CType(resources.GetObject("BtnStocks.BackgroundImage"),System.Drawing.Image)
        Me.BtnStocks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnStocks.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnStocks.FlatAppearance.BorderSize = 0
        Me.BtnStocks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnStocks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnStocks.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnStocks.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnStocks.ImageKey = "Coffee-Shop-icon.png"
        Me.BtnStocks.ImageList = Me.ButtonsImages
        Me.BtnStocks.Location = New System.Drawing.Point(0, 204)
        Me.BtnStocks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnStocks.Name = "BtnStocks"
        Me.BtnStocks.Size = New System.Drawing.Size(281, 34)
        Me.BtnStocks.TabIndex = 10
        Me.BtnStocks.Text = "بيانات المخازن"
        Me.BtnStocks.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnStocks.UseVisualStyleBackColor = false
        '
        'BtnCategories
        '
        Me.BtnCategories.BackColor = System.Drawing.Color.Transparent
        Me.BtnCategories.BackgroundImage = CType(resources.GetObject("BtnCategories.BackgroundImage"),System.Drawing.Image)
        Me.BtnCategories.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCategories.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCategories.FlatAppearance.BorderSize = 0
        Me.BtnCategories.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCategories.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCategories.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCategories.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCategories.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCategories.ImageKey = "shopping-cart.png"
        Me.BtnCategories.ImageList = Me.ButtonsImages
        Me.BtnCategories.Location = New System.Drawing.Point(0, 170)
        Me.BtnCategories.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCategories.Name = "BtnCategories"
        Me.BtnCategories.Size = New System.Drawing.Size(281, 34)
        Me.BtnCategories.TabIndex = 8
        Me.BtnCategories.Text = "بنود الاصناف الاساسيه"
        Me.BtnCategories.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCategories.UseVisualStyleBackColor = false
        '
        'BtnItemsStocks
        '
        Me.BtnItemsStocks.BackColor = System.Drawing.Color.Transparent
        Me.BtnItemsStocks.BackgroundImage = CType(resources.GetObject("BtnItemsStocks.BackgroundImage"),System.Drawing.Image)
        Me.BtnItemsStocks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnItemsStocks.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnItemsStocks.FlatAppearance.BorderSize = 0
        Me.BtnItemsStocks.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnItemsStocks.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnItemsStocks.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnItemsStocks.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnItemsStocks.ForeColor = System.Drawing.Color.White
        Me.BtnItemsStocks.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnItemsStocks.ImageKey = "1370453460_shoppingbasket_add.png"
        Me.BtnItemsStocks.ImageList = Me.ButtonsImages
        Me.BtnItemsStocks.Location = New System.Drawing.Point(0, 136)
        Me.BtnItemsStocks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnItemsStocks.Name = "BtnItemsStocks"
        Me.BtnItemsStocks.Size = New System.Drawing.Size(281, 34)
        Me.BtnItemsStocks.TabIndex = 5
        Me.BtnItemsStocks.Text = "إدخال أرصده أول مده"
        Me.BtnItemsStocks.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnItemsStocks.UseVisualStyleBackColor = false
        '
        'BtnUmDetails
        '
        Me.BtnUmDetails.BackColor = System.Drawing.Color.Transparent
        Me.BtnUmDetails.BackgroundImage = CType(resources.GetObject("BtnUmDetails.BackgroundImage"),System.Drawing.Image)
        Me.BtnUmDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnUmDetails.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnUmDetails.FlatAppearance.BorderSize = 0
        Me.BtnUmDetails.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnUmDetails.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnUmDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnUmDetails.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnUmDetails.ForeColor = System.Drawing.Color.White
        Me.BtnUmDetails.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnUmDetails.ImageKey = "Windows_View_Detail.png"
        Me.BtnUmDetails.ImageList = Me.ButtonsImages
        Me.BtnUmDetails.Location = New System.Drawing.Point(0, 102)
        Me.BtnUmDetails.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnUmDetails.Name = "BtnUmDetails"
        Me.BtnUmDetails.Size = New System.Drawing.Size(281, 34)
        Me.BtnUmDetails.TabIndex = 4
        Me.BtnUmDetails.Text = "تفاصيل مجموعه القياس "
        Me.BtnUmDetails.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnUmDetails.UseVisualStyleBackColor = false
        '
        'BtnUmMaster
        '
        Me.BtnUmMaster.BackColor = System.Drawing.Color.Transparent
        Me.BtnUmMaster.BackgroundImage = CType(resources.GetObject("BtnUmMaster.BackgroundImage"),System.Drawing.Image)
        Me.BtnUmMaster.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnUmMaster.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnUmMaster.FlatAppearance.BorderSize = 0
        Me.BtnUmMaster.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnUmMaster.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnUmMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnUmMaster.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnUmMaster.ForeColor = System.Drawing.Color.White
        Me.BtnUmMaster.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnUmMaster.ImageKey = "weight.png"
        Me.BtnUmMaster.ImageList = Me.ButtonsImages
        Me.BtnUmMaster.Location = New System.Drawing.Point(0, 68)
        Me.BtnUmMaster.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnUmMaster.Name = "BtnUmMaster"
        Me.BtnUmMaster.Size = New System.Drawing.Size(281, 34)
        Me.BtnUmMaster.TabIndex = 3
        Me.BtnUmMaster.Text = "مجموعه القياس"
        Me.BtnUmMaster.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnUmMaster.UseVisualStyleBackColor = false
        '
        'BtnCorporations
        '
        Me.BtnCorporations.BackColor = System.Drawing.Color.Transparent
        Me.BtnCorporations.BackgroundImage = CType(resources.GetObject("BtnCorporations.BackgroundImage"),System.Drawing.Image)
        Me.BtnCorporations.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCorporations.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnCorporations.FlatAppearance.BorderSize = 0
        Me.BtnCorporations.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnCorporations.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnCorporations.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnCorporations.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCorporations.ForeColor = System.Drawing.Color.White
        Me.BtnCorporations.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnCorporations.ImageKey = "company-building-icon.png"
        Me.BtnCorporations.ImageList = Me.ButtonsImages
        Me.BtnCorporations.Location = New System.Drawing.Point(0, 34)
        Me.BtnCorporations.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnCorporations.Name = "BtnCorporations"
        Me.BtnCorporations.Size = New System.Drawing.Size(281, 34)
        Me.BtnCorporations.TabIndex = 2
        Me.BtnCorporations.Text = "بيانات الشركات"
        Me.BtnCorporations.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnCorporations.UseVisualStyleBackColor = false
        '
        'BtnItems
        '
        Me.BtnItems.BackColor = System.Drawing.Color.Transparent
        Me.BtnItems.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_4123
        Me.BtnItems.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnItems.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnItems.FlatAppearance.BorderSize = 0
        Me.BtnItems.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnItems.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnItems.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnItems.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnItems.ImageKey = "1370457161_BeOS_blocks.png"
        Me.BtnItems.ImageList = Me.ButtonsImages
        Me.BtnItems.Location = New System.Drawing.Point(0, 0)
        Me.BtnItems.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnItems.Name = "BtnItems"
        Me.BtnItems.Size = New System.Drawing.Size(281, 34)
        Me.BtnItems.TabIndex = 1
        Me.BtnItems.Text = "الاصناف الاساسيه"
        Me.BtnItems.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnItems.UseVisualStyleBackColor = false
        '
        'PanelVendor
        '
        Me.PanelVendor.BackColor = System.Drawing.Color.Transparent
        Me.PanelVendor.Controls.Add(Me.BtnVendorReturns)
        Me.PanelVendor.Controls.Add(Me.BtnPurchaseBill)
        Me.PanelVendor.Controls.Add(Me.BtnItemsVendor)
        Me.PanelVendor.Controls.Add(Me.BtnVendors)
        Me.PanelVendor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelVendor.ForeColor = System.Drawing.Color.White
        Me.PanelVendor.Location = New System.Drawing.Point(0, 0)
        Me.PanelVendor.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelVendor.Name = "PanelVendor"
        Me.PanelVendor.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.PanelVendor.Size = New System.Drawing.Size(281, 838)
        Me.PanelVendor.TabIndex = 95
        Me.PanelVendor.Visible = false
        '
        'BtnVendorReturns
        '
        Me.BtnVendorReturns.BackgroundImage = CType(resources.GetObject("BtnVendorReturns.BackgroundImage"),System.Drawing.Image)
        Me.BtnVendorReturns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnVendorReturns.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnVendorReturns.FlatAppearance.BorderSize = 0
        Me.BtnVendorReturns.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnVendorReturns.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnVendorReturns.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnVendorReturns.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnVendorReturns.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnVendorReturns.ImageKey = "mypc_reload.png"
        Me.BtnVendorReturns.ImageList = Me.ButtonsImages
        Me.BtnVendorReturns.Location = New System.Drawing.Point(0, 102)
        Me.BtnVendorReturns.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnVendorReturns.Name = "BtnVendorReturns"
        Me.BtnVendorReturns.Size = New System.Drawing.Size(281, 34)
        Me.BtnVendorReturns.TabIndex = 23
        Me.BtnVendorReturns.Text = "إذن ارتجاع مورد"
        Me.BtnVendorReturns.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnVendorReturns.UseVisualStyleBackColor = true
        '
        'BtnPurchaseBill
        '
        Me.BtnPurchaseBill.BackgroundImage = CType(resources.GetObject("BtnPurchaseBill.BackgroundImage"),System.Drawing.Image)
        Me.BtnPurchaseBill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnPurchaseBill.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnPurchaseBill.FlatAppearance.BorderSize = 0
        Me.BtnPurchaseBill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnPurchaseBill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnPurchaseBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnPurchaseBill.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnPurchaseBill.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnPurchaseBill.ImageKey = "invoice.png"
        Me.BtnPurchaseBill.ImageList = Me.ButtonsImages
        Me.BtnPurchaseBill.Location = New System.Drawing.Point(0, 68)
        Me.BtnPurchaseBill.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnPurchaseBill.Name = "BtnPurchaseBill"
        Me.BtnPurchaseBill.Size = New System.Drawing.Size(281, 34)
        Me.BtnPurchaseBill.TabIndex = 21
        Me.BtnPurchaseBill.Text = "فواتير المشتريات"
        Me.BtnPurchaseBill.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnPurchaseBill.UseVisualStyleBackColor = true
        '
        'BtnItemsVendor
        '
        Me.BtnItemsVendor.BackgroundImage = CType(resources.GetObject("BtnItemsVendor.BackgroundImage"),System.Drawing.Image)
        Me.BtnItemsVendor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnItemsVendor.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnItemsVendor.FlatAppearance.BorderSize = 0
        Me.BtnItemsVendor.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnItemsVendor.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnItemsVendor.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnItemsVendor.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnItemsVendor.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnItemsVendor.ImageKey = "1370457161_BeOS_blocks.png"
        Me.BtnItemsVendor.ImageList = Me.ButtonsImages
        Me.BtnItemsVendor.Location = New System.Drawing.Point(0, 34)
        Me.BtnItemsVendor.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnItemsVendor.Name = "BtnItemsVendor"
        Me.BtnItemsVendor.Size = New System.Drawing.Size(281, 34)
        Me.BtnItemsVendor.TabIndex = 20
        Me.BtnItemsVendor.Text = "ربط المورديين بالاصناف"
        Me.BtnItemsVendor.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnItemsVendor.UseVisualStyleBackColor = true
        '
        'BtnVendors
        '
        Me.BtnVendors.BackgroundImage = CType(resources.GetObject("BtnVendors.BackgroundImage"),System.Drawing.Image)
        Me.BtnVendors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnVendors.Dock = System.Windows.Forms.DockStyle.Top
        Me.BtnVendors.FlatAppearance.BorderSize = 0
        Me.BtnVendors.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.BtnVendors.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.BtnVendors.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnVendors.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnVendors.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnVendors.ImageKey = "1370457133_BeOS_app_serv.png"
        Me.BtnVendors.ImageList = Me.ButtonsImages
        Me.BtnVendors.Location = New System.Drawing.Point(0, 0)
        Me.BtnVendors.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BtnVendors.Name = "BtnVendors"
        Me.BtnVendors.Size = New System.Drawing.Size(281, 34)
        Me.BtnVendors.TabIndex = 19
        Me.BtnVendors.Text = "بيانات المورديين"
        Me.BtnVendors.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.BtnVendors.UseVisualStyleBackColor = true
        '
        'Panel2
        '
        Me.Panel2.AutoScroll = true
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Panel7)
        Me.Panel2.Controls.Add(Me.Panel6)
        Me.Panel2.Controls.Add(Me.bydaily)
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Controls.Add(Me.bysubsc)
        Me.Panel2.Controls.Add(Me.GroupBox5)
        Me.Panel2.Controls.Add(Me.Button6)
        Me.Panel2.Controls.Add(Me.GroupBox1)
        Me.Panel2.Controls.Add(Me.GroupBox4)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 75)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(252, 838)
        Me.Panel2.TabIndex = 95
        Me.Panel2.Tag = "Shown"
        '
        'Panel7
        '
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.btnReceiv)
        Me.Panel7.Controls.Add(Me.Label9)
        Me.Panel7.Controls.Add(Me.Label6)
        Me.Panel7.Controls.Add(Me.CustBalance)
        Me.Panel7.Controls.Add(Me.CustAttendance)
        Me.Panel7.Location = New System.Drawing.Point(8, 230)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(233, 126)
        Me.Panel7.TabIndex = 143
        '
        'btnReceiv
        '
        Me.btnReceiv.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.btnReceiv.BackColor = System.Drawing.Color.Transparent
        Me.btnReceiv.BackgroundImage = Global.GYM.My.Resources.Resources.Back
        Me.btnReceiv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnReceiv.FlatAppearance.BorderSize = 0
        Me.btnReceiv.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.btnReceiv.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.btnReceiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReceiv.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnReceiv.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.btnReceiv.ImageKey = "up-icon.png"
        Me.btnReceiv.Location = New System.Drawing.Point(8, 2)
        Me.btnReceiv.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnReceiv.Name = "btnReceiv"
        Me.btnReceiv.Size = New System.Drawing.Size(28, 30)
        Me.btnReceiv.TabIndex = 142
        Me.btnReceiv.UseVisualStyleBackColor = false
        '
        'Label9
        '
        Me.Label9.AutoSize = true
        Me.Label9.Location = New System.Drawing.Point(78, 11)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 17)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "رصيد العميل"
        '
        'Label6
        '
        Me.Label6.AutoSize = true
        Me.Label6.Location = New System.Drawing.Point(66, 65)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(105, 17)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "عدد مرات الحضور"
        '
        'CustBalance
        '
        Me.CustBalance.BackColor = System.Drawing.SystemColors.Info
        Me.CustBalance.Enabled = false
        Me.CustBalance.Location = New System.Drawing.Point(8, 34)
        Me.CustBalance.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CustBalance.Name = "CustBalance"
        Me.CustBalance.Size = New System.Drawing.Size(214, 24)
        Me.CustBalance.TabIndex = 5
        Me.CustBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CustAttendance
        '
        Me.CustAttendance.BackColor = System.Drawing.SystemColors.Info
        Me.CustAttendance.Enabled = false
        Me.CustAttendance.Location = New System.Drawing.Point(8, 86)
        Me.CustAttendance.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CustAttendance.Name = "CustAttendance"
        Me.CustAttendance.Size = New System.Drawing.Size(214, 24)
        Me.CustAttendance.TabIndex = 4
        Me.CustAttendance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.Cost)
        Me.Panel6.Controls.Add(Me.Label8)
        Me.Panel6.Controls.Add(Me.dailysubsc)
        Me.Panel6.Controls.Add(Me.Label7)
        Me.Panel6.Location = New System.Drawing.Point(7, 534)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(233, 150)
        Me.Panel6.TabIndex = 142
        '
        'Cost
        '
        Me.Cost.BackColor = System.Drawing.SystemColors.Info
        Me.Cost.Enabled = false
        Me.Cost.Location = New System.Drawing.Point(7, 107)
        Me.Cost.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Cost.Name = "Cost"
        Me.Cost.Size = New System.Drawing.Size(214, 24)
        Me.Cost.TabIndex = 4
        Me.Cost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = true
        Me.Label8.Location = New System.Drawing.Point(94, 82)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(43, 17)
        Me.Label8.TabIndex = 139
        Me.Label8.Text = "السعر"
        '
        'dailysubsc
        '
        Me.dailysubsc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.dailysubsc.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.dailysubsc.FormattingEnabled = true
        Me.dailysubsc.Location = New System.Drawing.Point(6, 41)
        Me.dailysubsc.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dailysubsc.Name = "dailysubsc"
        Me.dailysubsc.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.dailysubsc.Size = New System.Drawing.Size(219, 31)
        Me.dailysubsc.TabIndex = 135
        '
        'Label7
        '
        Me.Label7.AutoSize = true
        Me.Label7.Location = New System.Drawing.Point(87, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.TabIndex = 5
        Me.Label7.Text = "الاشتراك"
        '
        'bydaily
        '
        Me.bydaily.AutoSize = true
        Me.bydaily.Location = New System.Drawing.Point(119, 503)
        Me.bydaily.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.bydaily.Name = "bydaily"
        Me.bydaily.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.bydaily.Size = New System.Drawing.Size(128, 21)
        Me.bydaily.TabIndex = 139
        Me.bydaily.Text = "الاشتراكات الوميه"
        Me.bydaily.UseVisualStyleBackColor = true
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Subscription_ID)
        Me.Panel3.Location = New System.Drawing.Point(7, 402)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(233, 93)
        Me.Panel3.TabIndex = 141
        '
        'Label4
        '
        Me.Label4.AutoSize = true
        Me.Label4.Location = New System.Drawing.Point(87, 15)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 17)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "الاشتراك"
        '
        'Subscription_ID
        '
        Me.Subscription_ID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Subscription_ID.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Subscription_ID.FormattingEnabled = true
        Me.Subscription_ID.Location = New System.Drawing.Point(6, 47)
        Me.Subscription_ID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Subscription_ID.Name = "Subscription_ID"
        Me.Subscription_ID.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Subscription_ID.Size = New System.Drawing.Size(219, 31)
        Me.Subscription_ID.TabIndex = 135
        '
        'bysubsc
        '
        Me.bysubsc.AutoSize = true
        Me.bysubsc.Checked = true
        Me.bysubsc.Location = New System.Drawing.Point(33, 370)
        Me.bysubsc.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.bysubsc.Name = "bysubsc"
        Me.bysubsc.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.bysubsc.Size = New System.Drawing.Size(222, 21)
        Me.bysubsc.TabIndex = 140
        Me.bysubsc.TabStop = true
        Me.bysubsc.Text = "حضور الاشتراكات الشهريه للعملاء"
        Me.bysubsc.UseVisualStyleBackColor = true
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.coach)
        Me.GroupBox5.Controls.Add(Me.Label5)
        Me.GroupBox5.Location = New System.Drawing.Point(6, 695)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox5.Size = New System.Drawing.Size(236, 91)
        Me.GroupBox5.TabIndex = 136
        Me.GroupBox5.TabStop = false
        Me.GroupBox5.Text = "المدربين"
        '
        'coach
        '
        Me.coach.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.coach.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.coach.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.coach.FormattingEnabled = true
        Me.coach.Location = New System.Drawing.Point(6, 44)
        Me.coach.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.coach.Name = "coach"
        Me.coach.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.coach.Size = New System.Drawing.Size(219, 31)
        Me.coach.TabIndex = 136
        '
        'Label5
        '
        Me.Label5.AutoSize = true
        Me.Label5.Location = New System.Drawing.Point(93, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 17)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "المدرب"
        '
        'Button6
        '
        Me.Button6.BackgroundImage = Global.GYM.My.Resources.Resources.button_smallBlue_search
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Location = New System.Drawing.Point(80, 796)
        Me.Button6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(87, 28)
        Me.Button6.TabIndex = 137
        Me.Button6.Text = "حفظ"
        Me.Button6.UseVisualStyleBackColor = true
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.EmpBarcode)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 5)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox1.Size = New System.Drawing.Size(236, 86)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = false
        Me.GroupBox1.Text = "حضور و انصراف الموظفين"
        '
        'Label1
        '
        Me.Label1.AutoSize = true
        Me.Label1.Location = New System.Drawing.Point(80, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "كود الموظف"
        '
        'EmpBarcode
        '
        Me.EmpBarcode.Location = New System.Drawing.Point(8, 47)
        Me.EmpBarcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.EmpBarcode.Name = "EmpBarcode"
        Me.EmpBarcode.Size = New System.Drawing.Size(214, 24)
        Me.EmpBarcode.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.custcode)
        Me.GroupBox4.Controls.Add(Me.Label2)
        Me.GroupBox4.Controls.Add(Me.Label3)
        Me.GroupBox4.Controls.Add(Me.custname)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 98)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox4.Size = New System.Drawing.Size(236, 124)
        Me.GroupBox4.TabIndex = 2
        Me.GroupBox4.TabStop = false
        Me.GroupBox4.Text = "العميل"
        '
        'custcode
        '
        Me.custcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.custcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.custcode.FormattingEnabled = true
        Me.custcode.Location = New System.Drawing.Point(6, 37)
        Me.custcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.custcode.Name = "custcode"
        Me.custcode.Size = New System.Drawing.Size(216, 24)
        Me.custcode.TabIndex = 28
        '
        'Label2
        '
        Me.Label2.AutoSize = true
        Me.Label2.Location = New System.Drawing.Point(83, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "كود العميل"
        '
        'Label3
        '
        Me.Label3.AutoSize = true
        Me.Label3.Location = New System.Drawing.Point(79, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "اسم العميل"
        '
        'custname
        '
        Me.custname.BackColor = System.Drawing.SystemColors.Info
        Me.custname.Enabled = false
        Me.custname.Location = New System.Drawing.Point(8, 89)
        Me.custname.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.custname.Name = "custname"
        Me.custname.Size = New System.Drawing.Size(214, 24)
        Me.custname.TabIndex = 2
        Me.custname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'SearchBox
        '
        Me.SearchBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.SearchBox.Location = New System.Drawing.Point(70, 26)
        Me.SearchBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.SearchBox.Name = "SearchBox"
        Me.SearchBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.SearchBox.Size = New System.Drawing.Size(203, 24)
        Me.SearchBox.TabIndex = 2
        '
        'PanelSearch
        '
        Me.PanelSearch.AutoScroll = true
        Me.PanelSearch.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PanelSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelSearch.Controls.Add(Me.Button7)
        Me.PanelSearch.Controls.Add(Me.GroupBox3)
        Me.PanelSearch.Controls.Add(Me.GroupBox2)
        Me.PanelSearch.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelSearch.Location = New System.Drawing.Point(252, 75)
        Me.PanelSearch.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PanelSearch.Name = "PanelSearch"
        Me.PanelSearch.Size = New System.Drawing.Size(648, 838)
        Me.PanelSearch.TabIndex = 143
        Me.PanelSearch.Tag = "Shown"
        Me.PanelSearch.Visible = false
        '
        'Button7
        '
        Me.Button7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.Button7.BackColor = System.Drawing.Color.Transparent
        Me.Button7.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_4123
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.Button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button7.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.Button7.ImageKey = "up-icon.png"
        Me.Button7.ImageList = Me.ButtonsImages
        Me.Button7.Location = New System.Drawing.Point(10, 5)
        Me.Button7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(522, 36)
        Me.Button7.TabIndex = 141
        Me.Button7.Text = "اخفاء"
        Me.Button7.UseVisualStyleBackColor = false
        '
        'GroupBox3
        '
        Me.GroupBox3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom)  _
            Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.GrdSearchDetails)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox3.Location = New System.Drawing.Point(7, 270)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox3.Size = New System.Drawing.Size(529, 546)
        Me.GroupBox3.TabIndex = 139
        Me.GroupBox3.TabStop = false
        Me.GroupBox3.Text = "تفاصيل البحث المحدد"
        '
        'GrdSearchDetails
        '
        Me.GrdSearchDetails.AllowUserToAddRows = false
        Me.GrdSearchDetails.AllowUserToDeleteRows = false
        Me.GrdSearchDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.GrdSearchDetails.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GrdSearchDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GrdSearchDetails.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GrdSearchDetails.Location = New System.Drawing.Point(3, 24)
        Me.GrdSearchDetails.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GrdSearchDetails.Name = "GrdSearchDetails"
        Me.GrdSearchDetails.ReadOnly = true
        Me.GrdSearchDetails.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GrdSearchDetails.RowHeadersVisible = false
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        Me.GrdSearchDetails.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.GrdSearchDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GrdSearchDetails.Size = New System.Drawing.Size(523, 518)
        Me.GrdSearchDetails.TabIndex = 28
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left)  _
            Or System.Windows.Forms.AnchorStyles.Right),System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.GrdSearch)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox2.Location = New System.Drawing.Point(7, 39)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GroupBox2.Size = New System.Drawing.Size(529, 230)
        Me.GroupBox2.TabIndex = 140
        Me.GroupBox2.TabStop = false
        Me.GroupBox2.Text = "نتائج البحث"
        '
        'GrdSearch
        '
        Me.GrdSearch.AllowUserToAddRows = false
        Me.GrdSearch.AllowUserToDeleteRows = false
        Me.GrdSearch.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.GrdSearch.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow
        Me.GrdSearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GrdSearch.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GrdSearch.Location = New System.Drawing.Point(3, 24)
        Me.GrdSearch.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GrdSearch.Name = "GrdSearch"
        Me.GrdSearch.ReadOnly = true
        Me.GrdSearch.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.GrdSearch.RowHeadersVisible = false
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(192,Byte),Integer), CType(CType(192,Byte),Integer), CType(CType(255,Byte),Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.GrdSearch.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.GrdSearch.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.GrdSearch.Size = New System.Drawing.Size(523, 202)
        Me.GrdSearch.TabIndex = 27
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = false
        Me.ToolStrip1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip1.BackgroundImage = Global.GYM.My.Resources.Resources.Bigbg
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BtnEmp, Me.BtnStock, Me.BtnCust, Me.BtnMedecine, Me.BtnAccounting, Me.BtnMost, Me.BtnReport, Me.BtnSecurity, Me.Show_Hide, Me.Button1})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.ToolStrip1.Size = New System.Drawing.Size(1498, 75)
        Me.ToolStrip1.TabIndex = 87
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'BtnEmp
        '
        Me.BtnEmp.AutoSize = false
        Me.BtnEmp.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_25Pressed1
        Me.BtnEmp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnEmp.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnEmp.ForeColor = System.Drawing.Color.Yellow
        Me.BtnEmp.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnEmp.ImageTransparentColor = System.Drawing.Color.White
        Me.BtnEmp.Name = "BtnEmp"
        Me.BtnEmp.Size = New System.Drawing.Size(100, 57)
        '
        'BtnStock
        '
        Me.BtnStock.AutoSize = false
        Me.BtnStock.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_21Pressed1
        Me.BtnStock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnStock.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnStock.ForeColor = System.Drawing.Color.Yellow
        Me.BtnStock.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnStock.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.BtnStock.Name = "BtnStock"
        Me.BtnStock.Size = New System.Drawing.Size(100, 57)
        '
        'BtnCust
        '
        Me.BtnCust.AutoSize = false
        Me.BtnCust.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_17Pressed1
        Me.BtnCust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCust.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnCust.ForeColor = System.Drawing.Color.Yellow
        Me.BtnCust.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnCust.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnCust.Name = "BtnCust"
        Me.BtnCust.Size = New System.Drawing.Size(100, 57)
        '
        'BtnMedecine
        '
        Me.BtnMedecine.AutoSize = false
        Me.BtnMedecine.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_19Pressed1
        Me.BtnMedecine.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnMedecine.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnMedecine.ForeColor = System.Drawing.Color.Yellow
        Me.BtnMedecine.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnMedecine.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnMedecine.Name = "BtnMedecine"
        Me.BtnMedecine.Size = New System.Drawing.Size(100, 57)
        '
        'BtnAccounting
        '
        Me.BtnAccounting.AutoSize = false
        Me.BtnAccounting.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_15Pressed
        Me.BtnAccounting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnAccounting.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnAccounting.ForeColor = System.Drawing.Color.Yellow
        Me.BtnAccounting.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnAccounting.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnAccounting.Name = "BtnAccounting"
        Me.BtnAccounting.Size = New System.Drawing.Size(100, 57)
        '
        'BtnMost
        '
        Me.BtnMost.AutoSize = false
        Me.BtnMost.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_09Pressed1
        Me.BtnMost.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnMost.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnMost.ForeColor = System.Drawing.Color.Yellow
        Me.BtnMost.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnMost.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnMost.Name = "BtnMost"
        Me.BtnMost.Size = New System.Drawing.Size(100, 57)
        '
        'BtnReport
        '
        Me.BtnReport.AutoSize = false
        Me.BtnReport.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_11Pressed1
        Me.BtnReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnReport.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnReport.ForeColor = System.Drawing.Color.Yellow
        Me.BtnReport.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnReport.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnReport.Name = "BtnReport"
        Me.BtnReport.Size = New System.Drawing.Size(100, 57)
        '
        'BtnSecurity
        '
        Me.BtnSecurity.AutoSize = false
        Me.BtnSecurity.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_03Pressed
        Me.BtnSecurity.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSecurity.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.BtnSecurity.ForeColor = System.Drawing.Color.Yellow
        Me.BtnSecurity.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.BtnSecurity.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnSecurity.Name = "BtnSecurity"
        Me.BtnSecurity.Size = New System.Drawing.Size(100, 57)
        '
        'Show_Hide
        '
        Me.Show_Hide.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.Show_Hide.AutoSize = false
        Me.Show_Hide.BackgroundImage = Global.GYM.My.Resources.Resources.Hide_Panel
        Me.Show_Hide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Show_Hide.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Show_Hide.ForeColor = System.Drawing.Color.Yellow
        Me.Show_Hide.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Show_Hide.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Show_Hide.Name = "Show_Hide"
        Me.Show_Hide.Size = New System.Drawing.Size(60, 60)
        Me.Show_Hide.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.Show_Hide.ToolTipText = "اظهار/اخفاء نافذة حضور الموظفين و العملاء"
        '
        'Button1
        '
        Me.Button1.AutoSize = false
        Me.Button1.BackgroundImage = Global.GYM.My.Resources.Resources.main_screen_07Pressed1
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0,Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Yellow
        Me.Button1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Button1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 57)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7!, 16!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1498, 913)
        Me.Controls.Add(Me.PanelSearch)
        Me.Controls.Add(Me.SearchBox)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.ToolStrip1)
        Me.IsMdiContainer = true
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Form1"
        Me.Opacity = 0R
        Me.RightToLeftLayout = true
        Me.ShowIcon = false
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "رؤيه للبرمجيات و النظم الاداريه - برنامج ادارة المراكز الرياضيه - الشاشه الرئيسيه"& _ 
    ""
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.PanelSettings.ResumeLayout(false)
        Me.PanelSecurity.ResumeLayout(false)
        Me.PanelEmployees.ResumeLayout(false)
        Me.Panel1.ResumeLayout(false)
        Me.Panel20.ResumeLayout(false)
        Me.Panel4.ResumeLayout(false)
        Me.PanelReports.ResumeLayout(false)
        Me.Panel8.ResumeLayout(false)
        Me.Panel5.ResumeLayout(false)
        Me.PanelAccounting.ResumeLayout(false)
        Me.Panel19.ResumeLayout(false)
        Me.Panel18.ResumeLayout(false)
        Me.Panel17.ResumeLayout(false)
        Me.Panel16.ResumeLayout(false)
        Me.Panel10.ResumeLayout(false)
        Me.PanelCustomer.ResumeLayout(false)
        Me.PanelStock.ResumeLayout(false)
        Me.PanelVendor.ResumeLayout(false)
        Me.Panel2.ResumeLayout(false)
        Me.Panel2.PerformLayout
        Me.Panel7.ResumeLayout(false)
        Me.Panel7.PerformLayout
        Me.Panel6.ResumeLayout(false)
        Me.Panel6.PerformLayout
        Me.Panel3.ResumeLayout(false)
        Me.Panel3.PerformLayout
        Me.GroupBox5.ResumeLayout(false)
        Me.GroupBox5.PerformLayout
        Me.GroupBox1.ResumeLayout(false)
        Me.GroupBox1.PerformLayout
        Me.GroupBox4.ResumeLayout(false)
        Me.GroupBox4.PerformLayout
        Me.PanelSearch.ResumeLayout(false)
        Me.GroupBox3.ResumeLayout(false)
        CType(Me.GrdSearchDetails,System.ComponentModel.ISupportInitialize).EndInit
        Me.GroupBox2.ResumeLayout(false)
        CType(Me.GrdSearch,System.ComponentModel.ISupportInitialize).EndInit
        Me.ToolStrip1.ResumeLayout(false)
        Me.ToolStrip1.PerformLayout
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Friend WithEvents BtnEmp As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnStock As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnCust As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnMedecine As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnAccounting As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnMost As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnReport As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnSecurity As System.Windows.Forms.ToolStripButton
    Friend WithEvents Button1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents PanelSettings As System.Windows.Forms.Panel
    Friend WithEvents BtnChatClient As System.Windows.Forms.Button
    Friend WithEvents BtnChatServer As System.Windows.Forms.Button
    Friend WithEvents BtnSystemCommands As System.Windows.Forms.Button
    Friend WithEvents BtnSetDefault As System.Windows.Forms.Button
    Friend WithEvents BtnShifts As System.Windows.Forms.Button
    Friend WithEvents BtnSettings As System.Windows.Forms.Button
    Friend WithEvents PanelSecurity As System.Windows.Forms.Panel
    Friend WithEvents BtnApp_Users As System.Windows.Forms.Button
    Friend WithEvents BtnSecurityGroupDetails As System.Windows.Forms.Button
    Friend WithEvents BtnSecurityGroupHeader As System.Windows.Forms.Button
    Friend WithEvents PanelEmployees As System.Windows.Forms.Panel
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents BtnEmployeesDiscounts As System.Windows.Forms.Button
    Friend WithEvents BtnDiscountCatergories As System.Windows.Forms.Button
    Friend WithEvents MenuDiscounts As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents BtnEmpRewards As System.Windows.Forms.Button
    Friend WithEvents BtnRewardsCategories As System.Windows.Forms.Button
    Friend WithEvents MenuRewards As System.Windows.Forms.Button
    Friend WithEvents BtnTasks As System.Windows.Forms.Button
    Friend WithEvents BtnVacations As System.Windows.Forms.Button
    Friend WithEvents BtnAttendance As System.Windows.Forms.Button
    Friend WithEvents BtnEmployees As System.Windows.Forms.Button
    Friend WithEvents BtnJobs As System.Windows.Forms.Button
    Friend WithEvents BtnDepartments As System.Windows.Forms.Button
    Friend WithEvents PanelReports As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents BtnActivatePanel As System.Windows.Forms.Button
    Friend WithEvents PanelStock As System.Windows.Forms.Panel
    Friend WithEvents BtnAdjustments As System.Windows.Forms.Button
    Friend WithEvents BtnCheckDetails As System.Windows.Forms.Button
    Friend WithEvents BtnCheckHeader As System.Windows.Forms.Button
    Friend WithEvents BtnItemsOut As System.Windows.Forms.Button
    Friend WithEvents BtnStocks As System.Windows.Forms.Button
    Friend WithEvents BtnCategories As System.Windows.Forms.Button
    Friend WithEvents BtnItemsStocks As System.Windows.Forms.Button
    Friend WithEvents BtnUmDetails As System.Windows.Forms.Button
    Friend WithEvents BtnUmMaster As System.Windows.Forms.Button
    Friend WithEvents BtnCorporations As System.Windows.Forms.Button
    Friend WithEvents BtnItems As System.Windows.Forms.Button
    Friend WithEvents PanelCustomer As System.Windows.Forms.Panel
    Friend WithEvents BtnSalesOrder As System.Windows.Forms.Button
    Friend WithEvents BtnCustomers As System.Windows.Forms.Button
    Friend WithEvents BtnCustomerSubscription As System.Windows.Forms.Button
    Friend WithEvents BtnSubDaily As System.Windows.Forms.Button
    Friend WithEvents BtnSubscriptions As System.Windows.Forms.Button
    Friend WithEvents BtnSubscripionsCategories As System.Windows.Forms.Button
    Friend WithEvents PanelVendor As System.Windows.Forms.Panel
    Friend WithEvents BtnVendorReturns As System.Windows.Forms.Button
    Friend WithEvents BtnPurchaseBill As System.Windows.Forms.Button
    Friend WithEvents BtnItemsVendor As System.Windows.Forms.Button
    Friend WithEvents BtnVendors As System.Windows.Forms.Button
    Friend WithEvents PanelAccounting As System.Windows.Forms.Panel
    Friend WithEvents MenuDepPro As System.Windows.Forms.Button
    Friend WithEvents MenuBalanceSheet As System.Windows.Forms.Button
    Friend WithEvents MenuBalanceBook As System.Windows.Forms.Button
    Friend WithEvents MenuMasterRecord As System.Windows.Forms.Button
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents MenuMoneyReceivable As System.Windows.Forms.Button
    Friend WithEvents MenuMoneyPayments As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents MenuBanks As System.Windows.Forms.Button
    Friend WithEvents MenuBanksAccounts As System.Windows.Forms.Button
    Friend WithEvents BtnVisa As System.Windows.Forms.Button
    Friend WithEvents Banks As System.Windows.Forms.Button
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents MenuCheques As System.Windows.Forms.Button
    Friend WithEvents MenuChequeStatus As System.Windows.Forms.Button
    Friend WithEvents Cheques As System.Windows.Forms.Button
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents MenuDailyProcedures As System.Windows.Forms.Button
    Friend WithEvents MenuNewProcedureTran As System.Windows.Forms.Button
    Friend WithEvents constraint As System.Windows.Forms.Button
    Friend WithEvents MenuDailyProNames As System.Windows.Forms.Button
    Friend WithEvents MenuIncomeDetailsByPeriod As System.Windows.Forms.Button
    Friend WithEvents Panel10 As System.Windows.Forms.Panel
    Friend WithEvents MenuExpensesOther As System.Windows.Forms.Button
    Friend WithEvents MenuExpensesHeader As System.Windows.Forms.Button
    Friend WithEvents MenuExpenses As System.Windows.Forms.Button
    Friend WithEvents BtnShiftsDetails As System.Windows.Forms.Button
    Friend WithEvents ButtonsImages As System.Windows.Forms.ImageList
    Friend WithEvents BtnCustomerReturns As System.Windows.Forms.Button
    Friend WithEvents BtnPayAllSalaries As System.Windows.Forms.Button
    Friend WithEvents MenuEmpAccounts As System.Windows.Forms.Button
    Friend WithEvents BtnPaySalary As System.Windows.Forms.Button
    Friend WithEvents BtnCustomersAttendance As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents BtnGymReports As System.Windows.Forms.Button
    Friend WithEvents BtnSpecialSubCa As System.Windows.Forms.Button
    Friend WithEvents PanelStatistics As System.Windows.Forms.Panel
    Friend WithEvents BtnLocations As System.Windows.Forms.Button
    Friend WithEvents BtnRegions As System.Windows.Forms.Button
    Friend WithEvents BtnCities As System.Windows.Forms.Button
    Friend WithEvents BtnCountries As System.Windows.Forms.Button
    Friend WithEvents BtnSpecialSub As System.Windows.Forms.Button
    Friend WithEvents BtnCompanies As System.Windows.Forms.Button
    Friend WithEvents BtnCustOrderEvaluation As System.Windows.Forms.Button
    Friend WithEvents BtnCustEvaluation As System.Windows.Forms.Button
    Friend WithEvents BtnEvaluationCategory As System.Windows.Forms.Button
    Friend WithEvents BtnPrintEmpCards As System.Windows.Forms.Button
    Friend WithEvents BtnPrintBarcode As System.Windows.Forms.Button
    Friend WithEvents BtnBackCard As System.Windows.Forms.Button
    Friend WithEvents RptIncome As System.Windows.Forms.Button
    Friend WithEvents BntSubscReturn As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Show_Hide As System.Windows.Forms.ToolStripButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents EmpBarcode As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents custname As System.Windows.Forms.TextBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents coach As System.Windows.Forms.ComboBox
    Friend WithEvents Subscription_ID As System.Windows.Forms.ComboBox
    Friend WithEvents dailysubsc As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents bysubsc As System.Windows.Forms.RadioButton
    Friend WithEvents bydaily As System.Windows.Forms.RadioButton
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Cost As System.Windows.Forms.TextBox
    Friend WithEvents BtnAttendanceLeave As System.Windows.Forms.Button
    Friend WithEvents BtnSalaryGroups As System.Windows.Forms.Button
    Friend WithEvents SearchBox As System.Windows.Forms.TextBox
    Friend WithEvents PanelSearch As System.Windows.Forms.Panel
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GrdSearchDetails As System.Windows.Forms.DataGridView
    Friend WithEvents GrdSearch As System.Windows.Forms.DataGridView
    Friend WithEvents btnreportEmployees As System.Windows.Forms.Button
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents CustBalance As System.Windows.Forms.TextBox
    Friend WithEvents CustAttendance As System.Windows.Forms.TextBox
    Friend WithEvents btnReceiv As System.Windows.Forms.Button
    Friend WithEvents custcode As System.Windows.Forms.ComboBox
    Friend WithEvents Panel8 As Panel
    Friend WithEvents BtnRptAccountsBalance As Button
    Friend WithEvents BtnAnyAccount As Button
    Friend WithEvents BtnReportItemExpiration As Button
    Friend WithEvents BtnStockDetails As Button
    Friend WithEvents BtnGeneralBalance As Button
    Friend WithEvents BtnRptItemsUm As Button
    Friend WithEvents BtnRptStockValue As Button
    Friend WithEvents BtnRptUserLog As Button
    Friend WithEvents BtnRptInvLog As Button
    Friend WithEvents BtnRptDepItems As Button
    Friend WithEvents BtnRptBarcode As Button
    Friend WithEvents BtnRptSalesOrder As Button
    Friend WithEvents BtnRptCustomersReturns As Button
    Friend WithEvents BtnRptVendorReturns As Button
    Friend WithEvents BtnRptPurchaseOrder As Button
    Friend WithEvents BtnRptAdjustments As Button
    Friend WithEvents Button2 As Button
End Class
